<?php
session_start();
date_default_timezone_set('America/Lima');

/* ===============================
   VALIDAR SESIÓN
================================ */
if (empty($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

/* ===============================
   VALIDAR ID PEDIDO
================================ */
if (empty($_POST['id_pedido'])) {
    die("Pedido inválido.");
}

$idPedido  = intval($_POST['id_pedido']);
$idUsuario = intval($_SESSION['usuario_id']);

/* ===============================
   CONEXIÓN BD
================================ */
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

/* ===============================
   CANCELAR SOLO SI ES DEL USUARIO
   Y SI ESTÁ PENDIENTE
================================ */
$stmt = $conn->prepare("
    UPDATE pedidos
    SET estado = 'Cancelado'
    WHERE id_pedido = ?
      AND id_usuario = ?
      AND estado = 'Pendiente'
");
$stmt->bind_param("ii", $idPedido, $idUsuario);
$stmt->execute();

/* ===============================
   VALIDAR RESULTADO
================================ */
if ($stmt->affected_rows === 0) {
    $stmt->close();
    die("No se pudo cancelar el pedido (ya fue procesado o no te pertenece).");
}

$stmt->close();

/* ===============================
   REDIRECCIÓN
================================ */
header("Location: mis_pedidos.php?cancelado=1");
exit();
  