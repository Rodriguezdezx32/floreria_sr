<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle='Pagina En Blanco'; 
$activePage='dashboard';
include 'includes/header.php';
?>
<?php include 'includes/sidebar.php'; ?>

<!-- FONT AWESOME (NECESARIO PARA MOSTRAR ÍCONOS) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
.card-custom {
    border-radius: 12px;
    overflow: hidden;
}
.table thead {
    background: #4e73df;
    color: white;
}
.btn-group a {
    margin-right: 5px;
}
</style>

<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        
        <?php include 'includes/topbar.php'; ?>

        <div class="container-fluid">

            <!-- Título -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">
                    <i class="fa-solid fa-file-invoice-dollar"></i> Sistema de Vaucher
                </h1>
            </div>
 

            <!-- Subir Vaucher -->
            <div class="card shadow card-custom mb-4">
                <div class="card-header bg-primary text-white">
                    <h5><i class="fa-solid fa-upload"></i> Agregar Nuevo Vaucher</h5>
                </div>

                <div class="card-body">

                    <form method="POST" action="CargarFicheros.php" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Seleccionar archivo:</label>
                            <input required type="file" class="form-control" name="file">
                        </div>

                        <button class="btn btn-primary">
                            <i class="fa-solid fa-cloud-arrow-up"></i> Cargar Archivo
                        </button>
                    </form>

                </div>
            </div>

            <!-- Tabla Descargas -->
            <div class="card shadow card-custom">
                <div class="card-header bg-success text-white">
                    <h5><i class="fa-solid fa-download"></i> Descargas Disponibles</h5>
                </div>

                <div class="card-body">
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nombre del Archivo</th>
                                <th>Descargar</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            $archivos = scandir("subidas");
                            $num = 0;

                            for ($i = 2; $i < count($archivos); $i++) {
                                $num++;
                            ?>
                            <tr>
                                <td><?= $num; ?></td>
                                <td><?= $archivos[$i]; ?></td>

                                <!-- Descargar -->
                                <td>
                                    <a href="subidas/<?= $archivos[$i]; ?>"
                                       download="<?= $archivos[$i]; ?>"
                                       class="btn btn-outline-primary btn-sm"
                                       title="Descargar">
                                        <i class="fa-solid fa-download"></i>
                                    </a>
                                </td>

                                <!-- Eliminar -->
                                <td>
                                    <a href="Eliminar.php?name=subidas/<?= $archivos[$i]; ?>"
                                       class="btn btn-outline-danger btn-sm"
                                       onclick="return confirm('¿Eliminar archivo?');"
                                       title="Eliminar">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                </div>
            </div>

        </div>

    </div>

    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="text-center my-auto">
                <span>Copyright &copy; Tu Sistema Web 2025</span>
            </div>
        </div>
    </footer>
</div>

<?php include 'includes/footer.php'; ?>
