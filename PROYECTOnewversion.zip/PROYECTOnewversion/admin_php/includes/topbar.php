<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Si NO hay sesión, evitar que entren sin iniciar
if (!isset($_SESSION['usuario_nombre'])) {
    header("Location: ../logout.php");
    exit;
}
?>

<style>
/* (TUS ESTILOS SE MANTIENEN IGUAL) */
</style>

<!-- Topbar -->
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Usuario -->
        <li class="nav-item dropdown no-arrow">

            <a class="nav-link dropdown-toggle d-flex align-items-center"
               href="#" id="userDropdown" role="button" data-toggle="dropdown">

                <!-- NOMBRE DEL USUARIO -->
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    <?= htmlspecialchars($_SESSION['usuario_nombre']); ?>
                </span>

                <!-- FOTO -->
                <img class="img-profile rounded-circle" 
                     src="img/undraw_profile.svg" width="38">
            </a>

            <!-- Dropdown CORREGIDO -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in">

                <a class="dropdown-item" href="cambiar_contraseña.php">
                    <i class="fas fa-key fa-sm fa-fw mr-2 text-gray-400"></i>
                    Cambiar Contraseña
                </a>

                <div class="dropdown-divider"></div>

                <a class="dropdown-item text-danger" href="logout.php">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-danger"></i>
                    Cerrar Sesión
                </a>

            </div>

        </li>

    </ul>

</nav>
<!-- End of Topbar -->
