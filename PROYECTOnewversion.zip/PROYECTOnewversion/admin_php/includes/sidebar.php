    <!-- sidebar placeholder -->
    <?php
    if (!isset($activePage)) $activePage = '';
    ?>

    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-dark accordion" 
        style="background: linear-gradient(180deg, #000000ff 0%, #9200afff 100%);" 
        id="accordionSidebar">

        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center"  >
            <div class="sidebar-brand-icon">
                <img src="../logo.png" alt="Logo" style="width:45px; height:45px; border-radius:10px;">
            </div>
            <div class="sidebar-brand-text mx-3"><sup>floreria_Sr</sup></div>
        </a>

        <hr class="sidebar-divider my-0">

        <hr class="sidebar-divider">

        <div class="sidebar-heading">Interfaz</div>

        <li class="nav-item">
            <a class="nav-link" href="../admin_php/index.php">
                <i class="fas fa-fw fa-users"></i>
                <span>Inicio</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../admin_php/usuarios.php">
                <i class="fas fa-fw fa-users"></i>
                <span>Usuarios</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="../admin_php/cliente.php">
                <i class="fas fa-fw fa-users"></i>
                <span>Cliente</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="../admin_php/articulos.php">
                <i class="fas fa-fw fa-boxes"></i>
                <span>Artículos</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="../admin_php/categorias.php">
                <i class="fas fa-fw fa-tags"></i>
                <span>Categorías</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="pedido.php">
                <i class="fas fa-fw fa-shopping-cart"></i>
                <span>Pedidos</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="subir_vaucher.php">
                <i class="fas fa-fw fa-file-upload"></i>
                <span>Vaucher</span>
            </a>
        </li>

        <hr class="sidebar-divider">

        

        <hr class="sidebar-divider d-none d-md-block">

        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
    <!-- End of Sidebar -->
