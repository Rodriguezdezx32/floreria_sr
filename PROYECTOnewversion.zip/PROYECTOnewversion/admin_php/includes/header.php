<?php
// includes/header.php
// Recibe (opcional) $pageTitle para el título dinámico.
if (!isset($pageTitle)) $pageTitle = 'Panel';
?>

<!DOCTYPE html>
<html lang="es">
<head>
<style>
/* FONDO GENERAL */
body {
    background: linear-gradient(180deg, #000000 0%, #4b0066 40%, #7a00a8 70%, #a000ff 100%);
    background-attachment: fixed;
    color: #fff;
}

/* SIDEBAR */
#accordionSidebar {
    background: linear-gradient(180deg, #000000 0%, #4b0066 40%, #7a00a8 70%, #a000ff 100%) !important;
}

/* TOPBAR */
.navbar, .topbar, #content nav.navbar {
    background: linear-gradient(90deg, #000000 0%, #7a00a8 60%, #a000ff 100%) !important;
    color: #fff !important;
}

/* TEXTO DEL TOPBAR */
.topbar .nav-link, 
.navbar-brand, 
.topbar .dropdown-toggle {
    color: #fff !important;
}

/* TARJETAS (CARDS) estilo glass */
.card {
    background-color: rgba(255,255,255,0.10) !important;
    backdrop-filter: blur(5px);
    border: 1px solid rgba(255,255,255,0.15);
    color: white;
}

/* TABLAS */
.table {
    background-color: rgba(0,0,0,0.35);
    color: white !important;
}

.table thead {
    background-color: rgba(0,0,0,0.65) !important;
    color: #fff;
}

.table tbody tr td {
    color: #fff !important;
}

/* BOTONES OSCUROS Y PÚRPURA */
.btn-primary {
    background: linear-gradient(180deg, #4b0066 0%, #7a00a8 70%, #a000ff 100%) !important;
    border: none;
}

.btn-warning, .btn-danger, .btn-success {
    color: white !important;
}

/* MODAL OSCURO */
.modal-content {
    background-color: rgba(20, 0, 30, 0.95);
    color: white;
    backdrop-filter: blur(6px);
}

</style>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?= htmlspecialchars($pageTitle) ?> - Mi Admin</title>

    <!-- Enlaces CSS (ajusta rutas si es necesario) -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


    <!-- Agrega aquí tus CSS personalizados -->
</head>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

    <?php
    // Aquí no cerramos wrapper: sidebar se incluirá después.
    // También puedes iniciar sesión o proteger la página aquí si quieres.
    ?>
    
