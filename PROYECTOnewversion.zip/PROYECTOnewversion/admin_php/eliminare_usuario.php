<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

$id = $_GET['id'] ?? 0;

$sql = "DELETE FROM usuarios WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
  echo "<script>alert('Usuario eliminado correctamente'); window.location='usuarios.php';</script>";
} else {
  echo "<script>alert('Error al eliminar usuario'); window.location='usuarios.php';</script>";
}

$stmt->close();
$conn->close();
?>
