<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle='Pagina En Blanco'; 
$activePage='dashboard';
include 'includes/header.php';
?>


<style>
/* === ESTILO DEL FORMULARIO DEL MODAL === */
.custom-input {
    background: #ffffff;
    color: #000;
    border-radius: 8px;
    border: none;
    padding: 10px;
}

.custom-input:focus {
    outline: 2px solid #00b6c7;
    box-shadow: none;
}

.modal-content {
    background: #110016 !important;
    color: white;
    border-radius: 12px;
}

.modal-header {
    background: #00b6c7 !important;
    border-radius: 12px 12px 0 0;
}

label {
    font-weight: bold;
}
</style>
<?php include 'includes/sidebar.php'; ?>

<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}
?>
<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        <?php include 'includes/topbar.php'; ?>

        <div class="container-fluid">
 <center>
    <h1 class="h3 mb-4 text-gray-800">Categorias</h1>
</center>

      <table class="table table-bordered table-hover">
        <thead class="table-dark">
          <tr>
            <th>ID Categoría</th>
            <th>Nombre</th>
            <th>Opciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $result = $conn->query("SELECT * FROM CATEGORIAS");
          while ($row = $result->fetch_assoc()):
          ?>
          <tr>
            <td><?= $row['id_categoria'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td>
              <!-- Botón editar -->
              <button class="btn btn-sm btn-warning"
                data-bs-toggle="modal"
                data-bs-target="#editModal"
                data-id="<?= $row['id_categoria'] ?>"
                data-nombre="<?= $row['nombre'] ?>">
                <i class="fa fa-edit"></i>
              </button>
              <!-- Botón eliminar -->
              <a href="eliminar_categoria.php?id=<?= $row['id_categoria'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro de eliminar esta categoría?');">
                <i class="fa fa-trash"></i>
              </a>
            </td>
          </tr>
          <?php endwhile; ?>

          <!-- Fila para agregar nueva categoría -->
          <tr class="table-success">
            <form action="agregar_categoria.php" method="POST">
              <td>Nuevo</td>
              <td>
                <input type="text" name="nombre" class="form-control" placeholder="Nombre de categoría" required>
              </td>
              <td>
                <button type="submit" class="btn btn-sm btn-success">
                  <i class="fa fa-plus"></i> Agregar
                </button>
              </td>
            </form>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal de edición -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="editar_categoria.php" method="POST">
        <div class="modal-header bg-info text-white">
          <h5 class="modal-title" id="editModalLabel"><i class="fa-solid fa-pen"></i> Editar Categoría</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_categoria" id="edit-id">
          <div class="mb-3">
            <label for="edit-nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" name="nombre" id="edit-nombre">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i> Guardar cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const editModal = document.getElementById('editModal');
  editModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    document.getElementById('edit-id').value = button.getAttribute('data-id');
    document.getElementById('edit-nombre').value = button.getAttribute('data-nombre');
  });
</script>

    
</div>

<?php include 'includes/footer.php'; ?>
