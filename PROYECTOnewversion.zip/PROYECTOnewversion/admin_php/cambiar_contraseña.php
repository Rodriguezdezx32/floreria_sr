<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../db.php';

/* Si no hay sesión, regresar a login */
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $idUsuario = $_SESSION['usuario_id'];
    $actual = $_POST['actual'];
    $nueva = $_POST['nueva'];
    $repetir = $_POST['repetir'];

    if ($nueva !== $repetir) {
        $mensaje = "❌ Las nuevas contraseñas no coinciden.";
    } else {

        // Obtener clave actual
        $sql = "SELECT clave FROM usuarios WHERE id_usuario = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $idUsuario);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {

            $stmt->bind_result($claveHash);
            $stmt->fetch();

            // Verificar clave actual
            if (password_verify($actual, $claveHash)) {

                $nuevoHash = password_hash($nueva, PASSWORD_DEFAULT);

                // Actualizar clave
                $sql2 = "UPDATE usuarios SET clave = ? WHERE id_usuario = ?";
                $stmt2 = $conn->prepare($sql2);
                $stmt2->bind_param("si", $nuevoHash, $idUsuario);
                $stmt2->execute();
                $stmt2->close();

                $mensaje = "✔️ Contraseña actualizada correctamente.";

            } else {
                $mensaje = "❌ La contraseña actual es incorrecta.";
            }

        } else {
            $mensaje = "❌ Usuario no encontrado.";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Cambiar Contraseña</title>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

<style>
body {
    background: #1a1a1a;
    color: white;
}

.card {
    background-color: rgba(255,255,255,0.08);
    backdrop-filter: blur(4px);
    border: 1px solid rgba(255,255,255,0.2);
}
</style>

</head>
<body>

<div class="container mt-5" style="max-width: 500px;">

    <div class="card p-4">

        <!-- Título morado -->
        <h3 style="color: #b07bff;" class="text-center mb-3">
            Cambiar Contraseña
        </h3>

        <?php if ($mensaje != ""): ?>
        <div class="alert alert-info"><?= $mensaje ?></div>
        <?php endif; ?>

        <form method="POST">

            <label>Contraseña Actual:</label>
            <input type="password" name="actual" class="form-control mb-3" required>

            <label>Nueva Contraseña:</label>
            <input type="password" name="nueva" class="form-control mb-3" required>

            <label>Repetir Nueva Contraseña:</label>
            <input type="password" name="repetir" class="form-control mb-4" required>

            <button class="btn btn-primary w-100">Actualizar Contraseña</button>
        </form>

        <a href="usuarios.php" class="btn btn-secondary w-100 mt-3">Volver</a>

    </div>
</div>

</body>
</html>
