<?php
include '../db.php';

// =====================
// DATOS DEL FORMULARIO
// =====================
$id           = $_POST['id_producto'];
$nombre       = $_POST['nombre'];
$descripcion  = $_POST['descripcion'];
$precio       = $_POST['precio'];
$stock        = $_POST['stock'];          // 👈 NUEVO
$id_categoria = $_POST['id_categoria'];

$imagen_final = "";

// =====================
// OBTENER IMAGEN ACTUAL
// =====================
$sqlImg = $conn->query("SELECT imagen_url FROM PRODUCTOS WHERE id_producto = $id");
$row = $sqlImg->fetch_assoc();
$imagen_actual = $row['imagen_url'];

// =====================
// MANEJO DE IMAGEN
// =====================
if (empty($_FILES['imagen']['name'])) {
    // No suben nueva imagen → mantener la actual
    $imagen_final = $imagen_actual;
} else {

    $dir = "../imagenes_productos/";
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }

    $fileName = time() . "_" . basename($_FILES["imagen"]["name"]);
    $rutaFinal = $dir . $fileName;

    if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $rutaFinal)) {

        // eliminar imagen anterior si existe
        if (!empty($imagen_actual) && file_exists($dir . $imagen_actual)) {
            unlink($dir . $imagen_actual);
        }

        $imagen_final = $fileName;
    } else {
        $imagen_final = $imagen_actual;
    }
}

// =====================
// ACTUALIZAR PRODUCTO
// =====================
$sql = "UPDATE PRODUCTOS
        SET nombre = ?, 
            descripcion = ?, 
            precio = ?, 
            stock = ?,          -- 👈 NUEVO
            imagen_url = ?, 
            id_categoria = ?
        WHERE id_producto = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssdisii",
    $nombre,
    $descripcion,
    $precio,
    $stock,
    $imagen_final,
    $id_categoria,
    $id
);

$stmt->execute();

header("Location: articulos.php");
exit();
?>
