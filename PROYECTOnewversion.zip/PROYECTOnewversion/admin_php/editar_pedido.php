<?php
// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

// Recibir datos del formulario
$id = $_POST['id'];
$estado = $_POST['estado'];

// Actualizar pedido
$sql = "UPDATE PEDIDOS SET estado = ? WHERE id_pedido = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $estado, $id);

if ($stmt->execute()) {
  echo "<script>alert('Pedido actualizado correctamente'); window.location='pedido.php';</script>";
} else {
  echo "<script>alert('Error al actualizar el pedido'); window.location='pedido.php';</script>";
}

$stmt->close();
$conn->close();
?>
