<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle='Pagina En Blanco'; 
$activePage='dashboard';
include 'includes/header.php';
?>
<?php include 'includes/sidebar.php'; ?>

<div id="content-wrapper" class="d-flex flex-column">
    <div id="content">
        <?php include 'includes/topbar.php'; ?>

        <div class="container-fluid">

            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Página en blanco</h1>
                <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                    <i class="fas fa-download fa-sm text-white-50"></i> Generar Reporte
                </a>
            </div>

            <div class="row">
                <div class="col">
                     Aqui va el contenido de tu página en blanco.
                </div>
            </div>

        </div>
    </div>

    <footer class="sticky-footer bg-white">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                <span>Copyright &copy; Tu Sistema Web 2025</span>
            </div>
        </div>
    </footer>
</div>

<?php include 'includes/footer.php'; ?>
