<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

$id = $_GET['id'];

$sql = "DELETE FROM CATEGORIAS WHERE id_categoria = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
  echo "<script>alert('Categoría eliminada correctamente'); window.location='categorias.php';</script>";
} else {
  echo "<script>alert('Error al eliminar la categoría'); window.location='categorias.php';</script>";
}

$stmt->close();
$conn->close();
?>
