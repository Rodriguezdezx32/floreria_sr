<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión");
}

$nombre    = $_POST['nombre'];
$correo    = $_POST['correo'];
$telefono  = $_POST['telefono'];
$direccion = $_POST['direccion'];
$rol       = $_POST['rol'];
$clave     = password_hash($_POST['clave'], PASSWORD_DEFAULT);
$creado_en = date("Y-m-d H:i:s");

$stmt = $conn->prepare(
    "INSERT INTO usuarios 
    (nombre, correo, telefono, direccion, rol, clave, creado_en) 
    VALUES (?, ?, ?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "sssssss",
    $nombre,
    $correo,
    $telefono,
    $direccion,
    $rol,
    $clave,
    $creado_en
);

$stmt->execute();

$stmt->close();
$conn->close();

header("Location: usuarios.php");
exit;
?>
