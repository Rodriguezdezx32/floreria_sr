<?php
include '../db.php';

$nombre        = $_POST['nombre'];
$descripcion   = $_POST['descripcion'];
$precio        = $_POST['precio'];
$stock         = $_POST['stock'];       // 👈 NUEVO
$id_categoria  = $_POST['id_categoria'];

$imagen_url = "";

/* =====================
   SUBIR IMAGEN
   ===================== */
if (!empty($_FILES['imagen']['name'])) {

    $directorio = "../imagenes_productos/";
    if (!is_dir($directorio)) {
        mkdir($directorio, 0777, true);
    }

    $nombreArchivo = time() . "_" . basename($_FILES["imagen"]["name"]);
    $rutaFinal = $directorio . $nombreArchivo;

    if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $rutaFinal)) {
        // Guardamos SOLO el nombre
        $imagen_url = $nombreArchivo;
    }
}

/* =====================
   INSERT CON STOCK
   ===================== */
$sql = "INSERT INTO PRODUCTOS 
        (nombre, descripcion, precio, stock, imagen_url, id_categoria)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssdisi",
    $nombre,
    $descripcion,
    $precio,
    $stock,
    $imagen_url,
    $id_categoria
);

$stmt->execute();

header("Location: articulos.php");
exit();
?>
