<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];
$rol = $_POST['rol'];
$clave = password_hash($_POST['clave'], PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE usuarios SET nombre=?, correo=?, telefono=?, direccion=?, rol=?, clave=? WHERE id_usuario=?");
$stmt->bind_param("ssssssi", $nombre, $correo, $telefono, $direccion, $rol, $clave, $id);

$stmt->execute();

header("Location: usuarios.php");
?>
