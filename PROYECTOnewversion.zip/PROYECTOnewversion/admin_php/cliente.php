<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle = 'Lista de Clientes';
$activePage = 'dashboard';

include 'includes/header.php';
include 'includes/sidebar.php';

// CONEXIÓN
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

/* =========================
   FILTROS
   ========================= */
$estado = $_GET['estado'] ?? '';
$direccion = trim($_GET['direccion'] ?? '');

$where = [];
$where[] = "rol = 'cliente'";

if ($estado === 'nuevo') {
    $where[] = "creado_en >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
} elseif ($estado === 'antiguo') {
    $where[] = "creado_en < DATE_SUB(NOW(), INTERVAL 7 DAY)";
}

if (!empty($direccion)) {
    $direccion_safe = $conn->real_escape_string($direccion);
    $where[] = "direccion LIKE '%$direccion_safe%'";
}

$whereSQL = "WHERE " . implode(" AND ", $where);

$sql = "
SELECT * FROM usuarios
$whereSQL
ORDER BY id_usuario DESC
";

$result = $conn->query($sql);
?>

<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<?php include 'includes/topbar.php'; ?>

<div class="container-fluid">

<center>
    <h1 class="h3 mb-4 text-gray-800">LISTA DE CLIENTES</h1>
</center>

<!-- =========================
     FORMULARIO DE FILTROS
     ========================= -->
<form method="GET" class="form-inline mb-3">

    <select name="estado" class="form-control mr-2">
        <option value="">Todos</option>
        <option value="nuevo" <?= $estado === 'nuevo' ? 'selected' : '' ?>>Clientes nuevos</option>
        <option value="antiguo" <?= $estado === 'antiguo' ? 'selected' : '' ?>>Clientes antiguos</option>
    </select>

    <input type="text"
           name="direccion"
           class="form-control mr-2"
           placeholder="Buscar por dirección"
           value="<?= htmlspecialchars($direccion) ?>">

    <button class="btn btn-primary">
        <i class="fas fa-search"></i> Filtrar
    </button>

</form>

<div class="card shadow">
<div class="card-body">
<div class="table-responsive">

<table class="table table-bordered table-hover text-center align-middle">
<thead class="thead-dark">
<tr>
    <th>ID</th>
    <th>Nombre</th>
    <th>Correo</th>
    <th>Teléfono</th>
    <th>Dirección</th>
    <th>Estado</th>
    <th>Rol</th>
    <th>Contraseña (hash)</th>
    <th>Acción</th>
</tr>
</thead>

<tbody>
<?php
$hoy = new DateTime();

while ($row = $result->fetch_assoc()):
    $fecha = new DateTime($row['creado_en']);
    $dias = $fecha->diff($hoy)->days;

    $estadoCliente = ($dias >= 7)
        ? '<span class="badge badge-success">Antiguo</span>'
        : '<span class="badge badge-primary">Nuevo</span>';
?>
<tr>
    <td><?= $row['id_usuario'] ?></td>
    <td><?= htmlspecialchars($row['nombre']) ?></td>
    <td><?= htmlspecialchars($row['correo']) ?></td>
    <td><?= htmlspecialchars($row['telefono']) ?></td>
    <td><?= htmlspecialchars($row['direccion']) ?></td>
    <td><?= $estadoCliente ?></td>
    <td><span class="badge badge-secondary">Cliente</span></td>

    <td style="max-width:160px; word-break:break-all;">
        <code style="font-size:10px;">
            <?= htmlspecialchars($row['clave']) ?>
        </code>
    </td>

    <td>
        <a href="eliminar_usuario.php?id=<?= $row['id_usuario'] ?>"
           class="btn btn-danger btn-sm"
           onclick="return confirm('¿Seguro de eliminar este cliente?');">
           <i class="fas fa-trash"></i>
        </a>
    </td>
</tr>
<?php endwhile; ?>
</tbody>

</table>

</div>
</div>
</div>

</div>
</div>
</div>

<?php include 'includes/footer.php'; ?>
