<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle='Articulos'; 
$activePage='dashboard';
include 'includes/header.php';
include 'includes/sidebar.php';
include '../db.php';
?>

<style>
.custom-input {
    background: #ffffff;
    color: #000;
    border-radius: 8px;
    border: none;
    padding: 10px;
}
.custom-input:focus {
    outline: 2px solid #00b6c7;
    box-shadow: none;
}
.modal-content {
    background: #110016 !important;
    color: white;
    border-radius: 12px;
}
.modal-header {
    background: #00b6c7 !important;
    border-radius: 12px 12px 0 0;
}
label { font-weight: bold; }
table td { vertical-align: middle; }
</style>

<?php
/* =====================
   FILTRO POR CATEGORÍA
   ===================== */
$categoriaFiltro = $_GET['categoria'] ?? '';
$where = "";

if (!empty($categoriaFiltro)) {
    $where = "WHERE p.id_categoria = " . (int)$categoriaFiltro;
}
?>

<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<?php include 'includes/topbar.php'; ?>

<div class="container-fluid">
<center>
    <h1 class="h3 mb-4 text-gray-800">Articulos</h1>
</center>
<!-- FILTRO -->
<form method="GET" class="mb-3" style="max-width:300px;">
<select name="categoria" class="form-select" onchange="this.form.submit()">
<option value="">Todas las categorías</option>
<?php
$cats = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS");
while ($cat = $cats->fetch_assoc()):
?>
<option value="<?= $cat['id_categoria'] ?>" <?= $categoriaFiltro == $cat['id_categoria'] ? 'selected' : '' ?>>
<?= htmlspecialchars($cat['nombre']) ?>
</option>
<?php endwhile; ?>
</select>
</form>

<div class="card shadow-sm">
<table class="table table-bordered table-hover">

<thead class="table-dark">
<tr>
<th>ID</th>
<th>Imagen</th>
<th>Nombre</th>
<th>Descripción</th>
<th>Precio</th>
<th>Stock</th>
<th>Categoría</th>
<th>Acciones</th>
</tr>
</thead>

<tbody>

<?php
$sql = "
SELECT p.id_producto, p.nombre, p.descripcion, p.precio,
       p.stock, p.imagen_url,
       c.nombre AS categoria, p.id_categoria
FROM PRODUCTOS p
JOIN CATEGORIAS c ON p.id_categoria = c.id_categoria
$where
ORDER BY p.id_producto DESC
";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()):
?>

<tr>
<td><?= $row['id_producto'] ?></td>
<td><?= $row['imagen_url'] ?: 'sin_imagen' ?></td>
<td><?= htmlspecialchars($row['nombre']) ?></td>
<td><?= htmlspecialchars($row['descripcion']) ?></td>
<td>S/ <?= number_format($row['precio'],2) ?></td>

<td>
<span class="badge <?= $row['stock'] > 0 ? 'bg-success' : 'bg-danger' ?>">
<?= $row['stock'] ?>
</span>
</td>

<td><?= htmlspecialchars($row['categoria']) ?></td>

<td>
<button class="btn btn-sm btn-warning"
data-bs-toggle="modal"
data-bs-target="#editModal"
data-id="<?= $row['id_producto'] ?>"
data-nombre="<?= htmlspecialchars($row['nombre']) ?>"
data-descripcion="<?= htmlspecialchars($row['descripcion']) ?>"
data-precio="<?= $row['precio'] ?>"
data-stock="<?= $row['stock'] ?>"
data-imagen="<?= $row['imagen_url'] ?>"
data-idcategoria="<?= $row['id_categoria'] ?>">
<i class="fa fa-edit"></i>
</button>

<a href="eliminar_producto.php?id=<?= $row['id_producto'] ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('¿Seguro de eliminar este producto?');">
<i class="fa fa-trash"></i>
</a>
</td>
</tr>

<?php endwhile; ?>

<!-- NUEVO PRODUCTO -->
<tr class="table-success">
<form action="agregar_producto.php" method="POST" enctype="multipart/form-data">

<td>Nuevo</td>
<td><input type="file" name="imagen" class="form-control custom-input"></td>
<td><input type="text" name="nombre" class="form-control custom-input" required></td>
<td><textarea name="descripcion" class="form-control custom-input" required></textarea></td>
<td><input type="number" step="0.01" name="precio" class="form-control custom-input" required></td>
<td><input type="number" name="stock" class="form-control custom-input" required></td>

<td>
<select name="id_categoria" class="form-select custom-input" required>
<option value="">Seleccione categoría</option>
<?php
$cat2 = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS");
while ($c = $cat2->fetch_assoc()):
?>
<option value="<?= $c['id_categoria'] ?>"><?= $c['nombre'] ?></option>
<?php endwhile; ?>
</select>
</td>

<td>
<button class="btn btn-success btn-sm w-100">
<i class="fa fa-plus"></i> Agregar
</button>
</td>

</form>
</tr>

</tbody>
</table>
</div>
</div>
</div>
</div>

<!-- MODAL EDITAR -->
<div class="modal fade" id="editModal">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">

<form action="editar_producto.php" method="POST" enctype="multipart/form-data">

<div class="modal-header">
<h5 class="modal-title">Editar Producto</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="hidden" name="id_producto" id="edit-id">

<label>Nombre</label>
<input type="text" id="edit-nombre" name="nombre" class="form-control custom-input">

<label class="mt-2">Descripción</label>
<textarea id="edit-descripcion" name="descripcion" class="form-control custom-input"></textarea>

<label class="mt-2">Precio</label>
<input type="number" step="0.01" id="edit-precio" name="precio" class="form-control custom-input">

<label class="mt-2">Stock</label>
<input type="number" id="edit-stock" name="stock" class="form-control custom-input">

<label class="mt-2">Imagen actual:</label>
<span id="edit-img-name" class="fw-bold text-info d-block mb-2"></span>

<label>Nueva imagen</label>
<input type="file" name="imagen" class="form-control custom-input">

<label class="mt-2">Categoría</label>
<select id="edit-id_categoria" name="id_categoria" class="form-select custom-input">
<?php
$cat3 = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS");
while ($c3 = $cat3->fetch_assoc()):
?>
<option value="<?= $c3['id_categoria'] ?>"><?= $c3['nombre'] ?></option>
<?php endwhile; ?>
</select>
</div>

<div class="modal-footer">
<button class="btn btn-success">Guardar Cambios</button>
</div>

</form>
</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

<script>
document.getElementById('editModal').addEventListener('show.bs.modal', e => {
const b = e.relatedTarget;
document.getElementById('edit-id').value = b.dataset.id;
document.getElementById('edit-nombre').value = b.dataset.nombre;
document.getElementById('edit-descripcion').value = b.dataset.descripcion;
document.getElementById('edit-precio').value = b.dataset.precio;
document.getElementById('edit-stock').value = b.dataset.stock;
document.getElementById('edit-id_categoria').value = b.dataset.idcategoria;
document.getElementById('edit-img-name').innerText = b.dataset.imagen || 'sin_imagen';
});
</script>

<?php include 'includes/footer.php'; ?>
