      <?php
      session_start();

      if (!isset($_SESSION['usuario_id'])) {
          header("Location: ../login.php");
          exit();
      }

      $pageTitle='Página en Blanco';
      $activePage='dashboard';
      include 'includes/header.php';
      ?>
      <?php include 'includes/sidebar.php'; ?>

      <div id="content-wrapper" class="d-flex flex-column">
          <div id="content">
              <?php include 'includes/topbar.php'; ?>

              <div class="container-fluid">
              <center>
    <h1 class="h3 mb-4 text-gray-800">LISTA DE USUARIOS</h1>
</center>
                
 
      <?php
      $conn = new mysqli("localhost", "root", "", "floreria_sr");
      if ($conn->connect_error) { die("Error de conexión: " . $conn->connect_error); }
      ?>
  <style>
  /* FONDO GENERAL */
  body {
      background: linear-gradient(180deg, #000000 0%, #4b0066 40%, #7a00a8 70%, #a000ff 100%);
      background-attachment: fixed;
      color: #fff;
  }

  /* SIDEBAR */
  #accordionSidebar {
      background: linear-gradient(180deg, #000000 0%, #4b0066 40%, #7a00a8 70%, #a000ff 100%) !important;
  }

  /* TOPBAR */
  .navbar, .topbar, #content nav.navbar {
      background: linear-gradient(90deg, #000000 0%, #7a00a8 60%, #a000ff 100%) !important;
      color: #fff !important;
  }

  /* TEXTO DEL TOPBAR */
  .topbar .nav-link, 
  .navbar-brand, 
  .topbar .dropdown-toggle {
      color: #fff !important;
  }

  /* TARJETAS (CARDS) estilo glass */
  .card {
      background-color: rgba(255,255,255,0.10) !important;
      backdrop-filter: blur(5px);
      border: 1px solid rgba(255,255,255,0.15);
      color: white;
  }

  /* TABLAS */
  .table {
      background-color: rgba(0,0,0,0.35);
      color: white !important;
  }

  .table thead {
      background-color: rgba(0,0,0,0.65) !important;
      color: #fff;
  }

  .table tbody tr td {
      color: #fff !important;
  }

  /* BOTONES OSCUROS Y PÚRPURA */
  .btn-primary {
      background: linear-gradient(180deg, #4b0066 0%, #7a00a8 70%, #a000ff 100%) !important;
      border: none;
  }

  .btn-warning, .btn-danger, .btn-success {
      color: white !important;
  }

  /* MODAL OSCURO */
  .modal-content {
      background-color: rgba(20, 0, 30, 0.95);
      color: white;
      backdrop-filter: blur(6px);
  }

  </style>

    

          <div class="card-body">

            <!-- RESPONSIVE TABLE (IMPORTANTE) -->
            <div class="table-responsive">
            <table class="table table-hover table-bordered text-center align-middle">
              <thead class="table-dark">
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Correo</th>
                  <th>Teléfono</th>
                  <th>Dirección</th>
                  <th>Rol</th>
                  <th>Clave (hash)</th>
                  <th>Acciones</th>
                </tr>
              </thead>

              <tbody>
                <?php
                $result = $conn->query("SELECT * FROM usuarios ORDER BY id_usuario DESC");
                while ($row = $result->fetch_assoc()):
                ?>
                <tr>
                  <td><?= $row['id_usuario'] ?></td>
                  <td><?= htmlspecialchars($row['nombre']) ?></td>
                  <td><?= htmlspecialchars($row['correo']) ?></td>
                  <td><?= htmlspecialchars($row['telefono']) ?></td>
                  <td><?= htmlspecialchars($row['direccion']) ?></td>
                  <td><?= ucfirst(htmlspecialchars($row['rol'])) ?></td>

                  <!-- COLUMNA HASH AJUSTADA -->
                  <td style="max-width:160px; word-break:break-all;">
                      <code style="font-size:10px;"><?= htmlspecialchars($row['clave']) ?></code>
                  </td>

                  <td>

                    <!-- EDITAR -->
                    <button class="btn btn-warning btn-sm"
                      data-bs-toggle="modal"
                      data-bs-target="#editModal"
                      data-id="<?= $row['id_usuario'] ?>"
                      data-nombre="<?= htmlspecialchars($row['nombre']) ?>"
                      data-correo="<?= htmlspecialchars($row['correo']) ?>"
                      data-telefono="<?= htmlspecialchars($row['telefono']) ?>"
                      data-direccion="<?= htmlspecialchars($row['direccion']) ?>"
                      data-rol="<?= htmlspecialchars($row['rol']) ?>">
                      <i class="fa fa-edit"></i> Editar
                    </button>

                    <!-- ELIMINAR -->
                    <a href="eliminar_usuario.php?id=<?= $row['id_usuario'] ?>"
                      class="btn btn-danger btn-sm"
                      onclick="return confirm('¿Seguro de eliminar este usuario?');">
                      <i class="fa fa-trash"></i>
                    </a>

                  </td>
                </tr>
                <?php endwhile; ?>

                <!-- AGREGAR NUEVO -->
                <tr class="table-success">
                  <form action="agregar_usuario.php" method="POST">
                    <td>Nuevo</td>
                    <td><input type="text" name="nombre" class="form-control" required></td>
                    <td><input type="email" name="correo" class="form-control" required></td>
                    <td><input type="text" name="telefono" class="form-control"></td>
                    <td><input type="text" name="direccion" class="form-control"></td>

                    <td>
                      <select name="rol" class="form-select" required>
                        <option value="cliente">Cliente</option>
                        <option value="admin">Administrador</option>
                      </select>
                    </td>

                    <td><input type="password" name="clave" class="form-control" required></td>

                    <td><button class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Agregar</button></td>
                  </form>
                </tr>

              </tbody>
            </table>
            </div> <!-- /table-responsive -->

          </div>
        </div>
      </div>

      <!-- MODAL EDITAR -->
      <div class="modal fade" id="editModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <form action="editar_usuario.php" method="POST">

              <div class="modal-header bg-info text-white">
                <h5 class="modal-title"><i class="fa-solid fa-user-pen"></i> Editar Usuario</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
              </div>

              <div class="modal-body">
                <input type="hidden" name="id" id="edit-id">

                <label>Nombre</label>
                <input type="text" name="nombre" id="edit-nombre" class="form-control mb-2" required>

                <label>Correo</label>
                <input type="email" name="correo" id="edit-correo" class="form-control mb-2" required>

                <label>Teléfono</label>
                <input type="text" name="telefono" id="edit-telefono" class="form-control mb-2">

                <label>Dirección</label>
                <textarea name="direccion" id="edit-direccion" class="form-control mb-2"></textarea>

                <label>Nueva contraseña (opcional)</label>
                <input type="password" name="clave" id="edit-clave" class="form-control mb-2">

                <label>Rol</label>
                <select name="rol" id="edit-rol" class="form-select">
                  <option value="cliente">Cliente</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>

              <div class="modal-footer">
                <button class="btn btn-success"> </i> Guardar</button>
              </div>

            </form>
          </div>
        </div>
      </div>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

      <script>
      // CARGAR DATOS AL MODAL SIN MOSTRAR HASH
      document.getElementById('editModal').addEventListener('show.bs.modal', e => {
          const b = e.relatedTarget;
          document.getElementById('edit-id').value = b.getAttribute('data-id');
          document.getElementById('edit-nombre').value = b.getAttribute('data-nombre');
          document.getElementById('edit-correo').value = b.getAttribute('data-correo');
          document.getElementById('edit-telefono').value = b.getAttribute('data-telefono');
          document.getElementById('edit-direccion').value = b.getAttribute('data-direccion');
          document.getElementById('edit-rol').value = b.getAttribute('data-rol');
          document.getElementById('edit-clave').value = "";  
      });
      </script>

      <?php include 'includes/footer.php'; ?>
