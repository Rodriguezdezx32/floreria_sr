-- MySQL dump 10.13  Distrib 8.0.34, for macos13 (arm64)
--
-- Host: localhost    Database: mis_gastos
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo` enum('Ingreso','Gasto') NOT NULL,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_categoria`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `categorias_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,1,'Alimentación','Gasto','2025-12-02 21:15:43'),(2,1,'Transporte','Gasto','2025-12-02 21:15:43'),(3,1,'Educación','Gasto','2025-12-02 21:15:43'),(4,1,'Servicios (Luz/Agua)','Gasto','2025-12-02 21:15:43'),(5,1,'Internet/Telefonía','Gasto','2025-12-02 21:15:43'),(6,1,'Salud','Gasto','2025-12-02 21:15:43'),(7,1,'Entretenimiento','Gasto','2025-12-02 21:15:43'),(8,1,'Bodega','Gasto','2025-12-02 21:15:43'),(9,1,'Movilidad (Taxi/Bus)','Gasto','2025-12-02 21:15:43'),(10,1,'Sueldo','Ingreso','2025-12-02 21:15:43'),(11,1,'Ventas Extras','Ingreso','2025-12-02 21:15:43'),(12,1,'Ahorro','Ingreso','2025-12-02 21:15:43');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos`
--

DROP TABLE IF EXISTS `movimientos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimientos` (
  `id_movimiento` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_categoria` int NOT NULL,
  `tipo` enum('Ingreso','Gasto') NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `descripcion` text,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_movimiento`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `movimientos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `movimientos_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=634 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos`
--

LOCK TABLES `movimientos` WRITE;
/*!40000 ALTER TABLE `movimientos` DISABLE KEYS */;
INSERT INTO `movimientos` VALUES (1,1,10,'Ingreso',2500.00,'2025-01-05','Pago de sueldo mensual','2025-12-02 21:16:06'),(2,1,11,'Ingreso',180.00,'2025-01-08','Venta de teclado en Marketplace','2025-12-02 21:16:06'),(3,1,10,'Ingreso',2500.00,'2025-02-05','Pago de sueldo mensual','2025-12-02 21:16:06'),(4,1,11,'Ingreso',250.00,'2025-02-15','Servicio de reparación de PC','2025-12-02 21:16:06'),(5,1,12,'Ingreso',150.00,'2025-02-20','Depósito a ahorro','2025-12-02 21:16:06'),(6,1,8,'Gasto',12.50,'2025-01-02','Compra en bodega: pan, leche','2025-12-02 21:16:06'),(7,1,1,'Gasto',28.00,'2025-01-03','Almuerzo menú','2025-12-02 21:16:06'),(8,1,9,'Gasto',3.50,'2025-01-04','Pasaje en combi','2025-12-02 21:16:06'),(9,1,2,'Gasto',6.00,'2025-01-06','Taxi por aplicativo','2025-12-02 21:16:06'),(10,1,4,'Gasto',85.00,'2025-01-10','Pago de luz Enel','2025-12-02 21:16:06'),(11,1,5,'Gasto',60.00,'2025-01-12','Pago de internet Movistar','2025-12-02 21:16:06'),(12,1,1,'Gasto',32.00,'2025-01-14','Cena en pollería','2025-12-02 21:16:06'),(13,1,8,'Gasto',9.80,'2025-01-15','Yape en bodega','2025-12-02 21:16:06'),(14,1,7,'Gasto',20.00,'2025-01-18','Entrada cine','2025-12-02 21:16:06'),(15,1,6,'Gasto',45.00,'2025-01-20','Compra medicamentos','2025-12-02 21:16:06'),(16,1,3,'Gasto',120.00,'2025-01-25','Pago de instituto','2025-12-02 21:16:06'),(17,1,9,'Gasto',4.00,'2025-02-01','Pasaje corredor','2025-12-02 21:16:06'),(18,1,1,'Gasto',30.00,'2025-02-02','Almuerzo menú','2025-12-02 21:16:06'),(19,1,8,'Gasto',15.90,'2025-02-03','Bodega - compras varias','2025-12-02 21:16:06'),(20,1,7,'Gasto',25.00,'2025-02-07','Netflix mensual','2025-12-02 21:16:06'),(21,1,4,'Gasto',90.00,'2025-02-10','Pago de agua Sedapal','2025-12-02 21:16:06'),(22,1,5,'Gasto',60.00,'2025-02-12','Pago internet Claro','2025-12-02 21:16:06'),(23,1,6,'Gasto',22.00,'2025-02-15','Consulta en botica','2025-12-02 21:16:06'),(24,1,2,'Gasto',7.50,'2025-02-18','Mototaxi - Plin','2025-12-02 21:16:06'),(25,1,1,'Gasto',28.00,'2025-02-19','Menú ejecutivo','2025-12-02 21:16:06'),(26,1,8,'Gasto',11.20,'2025-02-20','Bodega - recarga celular','2025-12-02 21:16:06'),(27,1,9,'Gasto',3.50,'2025-02-21','Pasaje en combi','2025-12-02 21:16:06'),(28,1,10,'Ingreso',2500.00,'2025-01-05','Sueldo Enero','2025-12-02 21:17:48'),(29,1,11,'Ingreso',200.00,'2025-01-10','Venta por Facebook','2025-12-02 21:17:48'),(30,1,4,'Gasto',85.00,'2025-01-12','Pago Luz Enero','2025-12-02 21:17:48'),(31,1,5,'Gasto',60.00,'2025-01-13','Internet Movistar','2025-12-02 21:17:48'),(32,1,1,'Gasto',32.00,'2025-01-14','Almuerzo menú','2025-12-02 21:17:48'),(33,1,9,'Gasto',3.50,'2025-01-15','Pasaje combi','2025-12-02 21:17:48');
/*!40000 ALTER TABLE `movimientos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `presupuestos`
--

DROP TABLE IF EXISTS `presupuestos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `presupuestos` (
  `id_presupuesto` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int NOT NULL,
  `id_categoria` int NOT NULL,
  `monto_limite` decimal(10,2) NOT NULL,
  `mes` varchar(7) NOT NULL,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_presupuesto`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `presupuestos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `presupuestos_ibfk_2` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `presupuestos`
--

LOCK TABLES `presupuestos` WRITE;
/*!40000 ALTER TABLE `presupuestos` DISABLE KEYS */;
INSERT INTO `presupuestos` VALUES (206,1,1,400.00,'2025-01','2025-01-01 00:00:00'),(207,1,2,120.00,'2025-01','2025-01-01 00:00:00'),(208,1,3,80.00,'2025-01','2025-01-01 00:00:00'),(209,1,4,150.00,'2025-01','2025-01-01 00:00:00'),(210,1,5,60.00,'2025-01','2025-01-01 00:00:00'),(211,1,6,200.00,'2025-01','2025-01-01 00:00:00'),(212,1,1,450.00,'2025-02','2025-02-01 00:00:00'),(213,1,2,100.00,'2025-02','2025-02-01 00:00:00'),(214,1,3,90.00,'2025-02','2025-02-01 00:00:00'),(215,1,4,160.00,'2025-02','2025-02-01 00:00:00'),(216,1,5,70.00,'2025-02','2025-02-01 00:00:00'),(217,1,6,210.00,'2025-02','2025-02-01 00:00:00');
/*!40000 ALTER TABLE `presupuestos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(120) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  `fecha_registro` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Benjamín Huanca','benjamin@huanca.org','$2y$10$abcdefghijklmnopqrstuv','2025-12-02 21:12:03');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-03  9:40:27
