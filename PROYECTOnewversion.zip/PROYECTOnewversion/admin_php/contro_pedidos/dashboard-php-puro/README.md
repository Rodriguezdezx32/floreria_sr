# Dashboard - Control de Gastos (PHP puro)

Este proyecto es un **dashboard en PHP puro** (sin frameworks) listo para integrarlo con tu base de datos MySQL. Incluye:

- **public/.htaccess**: Configura las reglas de reescritura de URL para el servidor web, permitiendo que todas las solicitudes se dirijan al archivo `index.php` a menos que se trate de un archivo o directorio existente.
  
- **public/index.php**: Punto de entrada de la aplicación. Inicia la sesión, incluye la configuración de la base de datos y el controlador del dashboard, y maneja el enrutamiento simple para mostrar el dashboard o devolver un error 404.
  
- **app/config/database.php**: Contiene la clase `Database`, que gestiona la conexión a la base de datos MySQL utilizando PDO. Define las credenciales de conexión y el método `connect()` para establecer la conexión.
  
- **app/controllers/DashboardController.php**: Define la clase `DashboardController`, que maneja la lógica del dashboard. Tiene un método `index()` que obtiene datos de gastos, ingresos, categorías y presupuestos, y luego renderiza la vista correspondiente.
  
- **app/models/Movimiento.php**: Define la clase `Movimiento`, que interactúa con la tabla `movimientos` en la base de datos. Incluye métodos para obtener datos como el total de gastos por mes, ingresos versus gastos, gastos por categoría, y más.
  
- **app/models/Presupuesto.php**: Define la clase `Presupuesto`, que interactúa con la tabla `presupuestos`. Incluye métodos para obtener presupuestos por mes y comparar el presupuesto con lo gastado.
  
- **app/views/layouts/base.php**: Plantilla base para las vistas. Incluye el encabezado HTML, enlaces a Bootstrap y Chart.js, y un formulario para filtrar los datos del dashboard.
  
- **app/views/dashboard/index.php**: Renderiza el contenido del dashboard, mostrando gráficos y datos sobre gastos, ingresos, y presupuestos. Utiliza Chart.js para mostrar gráficos interactivos.
  
- **.gitignore**: Especifica qué archivos o directorios deben ser ignorados por Git, como archivos temporales o de configuración local.

## Instrucciones de configuración

1. Clona el repositorio en tu máquina local.
2. Asegúrate de tener un servidor web (como Apache) y PHP instalados.
3. Configura las credenciales de la base de datos en `app/config/database.php`.
4. Crea las tablas necesarias en tu base de datos (`usuarios`, `categorias`, `movimientos`, `presupuestos`).
5. Accede a la aplicación a través de tu navegador en `http://localhost/dashboard-php-puro/public`.

## Uso

Una vez configurado, puedes utilizar el dashboard para controlar tus gastos, visualizar tus ingresos y comparar con tus presupuestos. Utiliza el formulario para filtrar los datos por mes.