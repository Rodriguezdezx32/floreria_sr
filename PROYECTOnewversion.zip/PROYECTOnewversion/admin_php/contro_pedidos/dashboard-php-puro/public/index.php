<?php
session_start();
require_once __DIR__ . '/../app/config/database.php';
require_once __DIR__ . '/../app/controllers/DashboardController.php';

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Normalizar ruta de forma robusta (soporta prefijos /public y evita problemas con query string)
$scriptDir = str_replace('\\','/', rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'));

if ($scriptDir !== '' && $scriptDir !== '/' && strpos($uri, $scriptDir) === 0) {
    $path = substr($uri, strlen($scriptDir));
} else {
    $path = $uri;
}
$path = $path === '' ? '/' : $path;

// Simple routing
if ($path === '/' || $path === '/dashboard' || $path === '/index.php') {
    $ctrl = new DashboardController();
    $ctrl->index();
    exit;
}

http_response_code(404);
echo '404 - Not Found';