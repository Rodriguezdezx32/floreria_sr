<?php
require_once __DIR__ . '/../models/Pedido.php';

class DashboardController {

    public function index() {
        $pedido = new Pedido();

        $year = date('Y');

        // Datos desde pedidos
        $ventasPorMes  = $pedido->getTotalByMonth($year);
        $topPedidos    = $pedido->getTopPedidos(10);
        $ventasDiarias = $pedido->getDailyTotals();

        // Mapeo a las variables que ya usa tu vista
        $totalByMonth = array_map(function($r) {
            return [
                'mes' => $r['mes'],
                'total_gastado' => $r['total_vendido']
            ];
        }, $ventasPorMes);

        $incomeVsExpense = array_map(function($r) {
            return [
                'mes' => $r['mes'],
                'total_ingresos' => $r['total_vendido'],
                'total_gastos' => 0
            ];
        }, $ventasPorMes);

        $topExpenses = array_map(function($p) {
            return [
                'descripcion' => 'Pedido #' . $p['id_pedido'],
                'monto' => $p['total']
            ];
        }, $topPedidos);

        $daily = array_map(function($d) {
            return [
                'dia' => $d['dia'],
                'total_gastado' => $d['total_vendido']
            ];
        }, $ventasDiarias);

        // variables que ya no se usan
        $byCategory = [];
        $budgetVsSpent = [];

        // envía a vista
        $year = $year;
        $month = date('Y-m');
        $content = __DIR__ . '/../views/dashboard/index.php';

        include __DIR__ . '/../views/layouts/base.php';
    }
}
