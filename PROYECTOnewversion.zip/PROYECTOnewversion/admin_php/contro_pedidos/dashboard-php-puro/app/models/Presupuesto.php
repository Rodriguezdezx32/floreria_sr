<?php
require_once __DIR__ . '/../config/database.php';

class Presupuesto {
    private $conn;
    private $table = 'presupuestos';

    public function __construct() {
        $db = new Database();
        $this->conn = $db->connect();
    }

    /**
     * Devuelve por cada categoría el presupuesto y lo gastado en ese mes (formato 'YYYY-MM').
     * Si no hay datos en presupuestos para el mes, devuelve array vacío.
     */
    public function getBudgetVsSpent($yearMonth) {
        if (!$yearMonth) return [];

        $sql = "
        SELECT
            p.id_categoria,
            COALESCE(c.nombre, 'Sin categoría') AS categoria,
            SUM(p.monto_limite) AS presupuesto,
            COALESCE(SUM(m_gastado.total_gastado), 0) AS gastado
        FROM {$this->table} p
        LEFT JOIN categorias c ON p.id_categoria = c.id_categoria
        -- sumamos gastos desde movimientos filtrando por mes y categoría
        LEFT JOIN (
            SELECT id_categoria, SUM(monto) AS total_gastado
            FROM movimientos
            WHERE tipo = 'Gasto' AND DATE_FORMAT(fecha, '%Y-%m') = :ym
            GROUP BY id_categoria
        ) m_gastado ON m_gastado.id_categoria = p.id_categoria
        WHERE p.mes = :ym
        GROUP BY p.id_categoria, c.nombre
        ORDER BY presupuesto DESC, categoria ASC
        ";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':ym' => $yearMonth]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $rows ?: [];
    }
}