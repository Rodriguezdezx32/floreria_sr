require_once __DIR__ . '/../models/Pedido.php';

class DashboardController {
    public function index() {

        $pedido = new Pedido();

        $year = date('Y');

        $ventasPorMes = $pedido->getTotalByMonth($year);
        $topPedidos = $pedido->getTopPedidos(5);
        $ventasDiarias = $pedido->getDailyTotals();

        include __DIR__ . '/../views/dashboard.php';
    }
}
