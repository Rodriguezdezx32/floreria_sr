<?php
require_once __DIR__ . '/../config/database.php';

class Pedido {
    private $conn;
    private $table = "pedidos";

    public function __construct() {
        $db = new Database();
        $this->conn = $db->connect();
    }

    // ventas por mes
    public function getTotalByMonth($year) {
        $sql = "SELECT DATE_FORMAT(fecha, '%Y-%m') AS mes,
                       SUM(total) AS total_vendido
                FROM {$this->table}
                WHERE YEAR(fecha) = :year
                GROUP BY mes
                ORDER BY mes ASC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([':year' => $year]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // top pedidos
    public function getTopPedidos($limit = 10) {
        $sql = "SELECT id_pedido, total, fecha
                FROM {$this->table}
                ORDER BY total DESC
                LIMIT :lim";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // ventas diarias
    public function getDailyTotals() {
        $sql = "SELECT DATE(fecha) AS dia,
                       SUM(total) AS total_vendido
                FROM {$this->table}
                GROUP BY dia
                ORDER BY dia DESC
                LIMIT 30";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
