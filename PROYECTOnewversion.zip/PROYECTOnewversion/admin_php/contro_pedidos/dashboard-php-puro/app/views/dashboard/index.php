<?php
$months = array_column($totalByMonth, 'mes');
$totals = array_column($totalByMonth, 'total_gastado');

$incMes = array_column($incomeVsExpense, 'total_ingresos');
$mesLabels = array_column($incomeVsExpense, 'mes');

$topDesc = array_column($topExpenses, 'descripcion');
$topMonto = array_column($topExpenses, 'monto');
?>

<div class="row mb-4">
  <div class="col-md-6">
    <div class="card p-3">
      <h6>Total ventas <?= $year ?></h6>
      <h3>S/ <?= number_format(array_sum($totals),2) ?></h3>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card p-3">
      <h6>Ventas por mes actual</h6>
      <?php
        $mVenta = 0;
        foreach($incomeVsExpense as $r) if($r['mes']==$month) $mVenta = $r['total_ingresos'];
      ?>
      <h3>S/ <?= number_format($mVenta,2) ?></h3>
    </div>
  </div>
</div>

<div class="card p-3 mb-3">
  <h5>Ventas por mes</h5>
  <canvas id="chartMonth"></canvas>
</div>

<div class="card p-3 mb-3">
  <h5>Ventas diarias (últimos 30 días)</h5>
  <canvas id="chartDaily"></canvas>
</div>

  <div class="card p-3 mb-3">
    <h5>Top pedidos</h5>
    <ul class="list-group">
      <?php foreach($topExpenses as $t): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
          <?= htmlspecialchars($t['descripcion']) ?>
          <span class="badge bg-primary">S/ <?= number_format($t['monto'],2) ?></span>
        </li>
      <?php endforeach; ?>
    </ul>
  </div>

<script>
const labelsMonth = <?= json_encode($months) ?>;
const dataMonth = <?= json_encode($totals) ?>;

new Chart(document.getElementById('chartMonth'), {
    type: 'bar',
    data: {
        labels: labelsMonth,
        datasets: [{ label: 'Ventas', data: dataMonth }]
    }
});

// diario
const dailyData = <?= json_encode(array_column($daily, 'total_gastado')) ?>;
const dailyLabels = <?= json_encode(array_column($daily, 'dia')) ?>;

new Chart(document.getElementById('chartDaily'), {
    type: 'line',
    data: {
        labels: dailyLabels,
        datasets: [{ label: 'Ventas diarias', data: dailyData }]
    }
});
</script>
