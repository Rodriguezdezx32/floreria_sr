<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Dashboard Ventas</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <span class="navbar-brand">ESTADISTICAS DE PEDIDOS </span>
    </div>
</nav>

<div class="container mt-4">
    <?php include $content; ?>
 
</center>
</body>
</html>
