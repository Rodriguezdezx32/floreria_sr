<?php
// ===============================
// SESIÓN (SOLO UNA VEZ)
// ===============================
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

// ===============================
// CONFIGURACIÓN DE LA PÁGINA
// ===============================
$pageTitle  = 'Panel de Pedidos';
$activePage = 'dashboard';

// ===============================
// INCLUDES BASE
// ===============================
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<?php include 'includes/topbar.php'; ?>

<div class="container-fluid">

    <center>
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Panel de Pedidos</h1>
        </div>
    </center>

<?php
// ===============================
// CONEXIÓN BD PRINCIPAL
// ===============================
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// ===============================
// DASHBOARD MVC (PEDIDOS)
// ===============================
require_once __DIR__ . '/contro_pedidos/dashboard-php-puro/app/config/database.php';
require_once __DIR__ . '/contro_pedidos/dashboard-php-puro/app/controllers/DashboardController.php';

// ===============================
// ROUTER SIMPLE
// ===============================
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$scriptDir = str_replace('\\', '/', rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\'));

if ($scriptDir !== '' && $scriptDir !== '/' && strpos($uri, $scriptDir) === 0) {
    $path = substr($uri, strlen($scriptDir));
} else {
    $path = $uri;
}

$path = $path === '' ? '/' : $path;

// ===============================
// RUTAS
// ===============================
if ($path === '/' || $path === '/dashboard' || $path === '/index.php') {
    $controller = new DashboardController();
    $controller->index();
} else {
    http_response_code(404);
    echo "<div class='alert alert-danger'>404 - Página no encontrada</div>";
}
?>

</div> <!-- container-fluid -->
</div> <!-- content -->
</div> <!-- content-wrapper -->

<?php include 'includes/footer.php'; ?>
