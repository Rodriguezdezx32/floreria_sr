<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) { die("Error de conexión: " . $conn->connect_error); }

$id = $_GET['id'];

$sql = "DELETE FROM PRODUCTOS WHERE id_producto = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
  echo "<script>alert('Producto eliminado correctamente'); window.location='articulos.php';</script>";
} else {
  echo "<script>alert('Error al eliminar producto'); window.location='articulos.php';</script>";
}

$stmt->close();
$conn->close();
?>
