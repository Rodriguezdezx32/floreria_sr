<style>
.custom-input {
    background: #ffffff;
    color: #000;
    border-radius: 8px;
    border: none;
    padding: 10px;
}
.custom-input:focus {
    outline: 2px solid #00b6c7;
    box-shadow: none;
}
.modal-content {
    background: #110016 !important;
    color: white;
    border-radius: 12px;
}
.modal-header {
    background: #00b6c7 !important;
    border-radius: 12px 12px 0 0;
}
label {
    font-weight: bold;
}
</style>

<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit();
}

$pageTitle='Pedidos';
$activePage='dashboard';
include 'includes/header.php';
include 'includes/sidebar.php';

$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

/* =====================
   FILTRO POR ESTADO
   ===================== */
$estadoFiltro = $_GET['estado'] ?? '';

$where = "";
if (!empty($estadoFiltro)) {
    $estadoSeguro = $conn->real_escape_string($estadoFiltro);
    $where = "WHERE estado = '$estadoSeguro'";
}

$query = "SELECT id_pedido, id_usuario, fecha, total, estado FROM pedidos $where ORDER BY id_pedido DESC";
$result = $conn->query($query);
?>

<div id="content-wrapper" class="d-flex flex-column">
<div id="content">
<?php include 'includes/topbar.php'; ?>

<div class="container-fluid">
<center>
    <h1 class="h3 mb-4 text-gray-800">Pedidos</h1>
</center>
 

<!-- FILTRO -->
<form method="GET" class="mb-3" style="max-width:300px;">
<select name="estado" class="form-select" onchange="this.form.submit()">
    <option value="">Todos los estados</option>
    <?php
    $estados = ['Pendiente','Procesando','Enviado','Entregado','Cancelado'];
    foreach ($estados as $e):
    ?>
        <option value="<?= $e ?>" <?= $estadoFiltro === $e ? 'selected' : '' ?>>
            <?= $e ?>
        </option>
    <?php endforeach; ?>
</select>
</form>

<div class="card shadow-sm">
<table class="table table-bordered table-hover">

<thead class="table-dark">
<tr>
<th>ID Pedido</th>
<th>ID Usuario</th>
<th>Fecha</th>
<th>Total</th>
<th>Estado</th>
<th>Opciones</th>
</tr>
</thead>

<tbody>
<?php while ($row = $result->fetch_assoc()): ?>
<tr>
<td><?= $row['id_pedido'] ?></td>
<td><?= $row['id_usuario'] ?></td>
<td><?= $row['fecha'] ?></td>
<td>S/ <?= number_format($row['total'], 2) ?></td>

<td>
<span class="badge bg-info"><?= $row['estado'] ?></span>
</td>

<td>
<button class="btn btn-sm btn-warning"
data-bs-toggle="modal"
data-bs-target="#editModal"
data-id="<?= $row['id_pedido'] ?>"
data-usuario="<?= $row['id_usuario'] ?>"
data-fecha="<?= $row['fecha'] ?>"
data-total="<?= $row['total'] ?>"
data-estado="<?= $row['estado'] ?>">
<i class="fa fa-edit"></i>
</button>

<a href="eliminar_pedido.php?id=<?= $row['id_pedido'] ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('¿Seguro de eliminar este pedido?');">
<i class="fa fa-trash"></i>
</a>
</td>
</tr>
<?php endwhile; ?>
</tbody>

</table>
</div>
</div>
</div>
</div>

<!-- MODAL EDITAR -->
<div class="modal fade" id="editModal">
<div class="modal-dialog">
<div class="modal-content">

<form action="editar_pedido.php" method="POST">

<div class="modal-header">
<h5 class="modal-title"><i class="fa fa-edit"></i> Editar Pedido</h5>
<button class="btn-close" data-bs-dismiss="modal"></button>
</div>

<div class="modal-body">
<input type="hidden" name="id" id="edit-id">

<div class="mb-2">
<label>ID Usuario</label>
<input type="text" id="edit-usuario" class="form-control" disabled>
</div>

<div class="mb-2">
<label>Fecha</label>
<input type="text" id="edit-fecha" class="form-control" disabled>
</div>

<div class="mb-2">
<label>Total</label>
<input type="text" id="edit-total" class="form-control" disabled>
</div>

<div class="mb-2">
<label>Estado</label>
<select class="form-select" name="estado" id="edit-estado">
<option>Pendiente</option>
<option>Procesando</option>
<option>Enviado</option>
<option>Entregado</option>
<option>Cancelado</option>
</select>
</div>
</div>

<div class="modal-footer">
<button class="btn btn-success">
<i class="fa fa-save"></i> Guardar
</button>
</div>

</form>

</div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('editModal').addEventListener('show.bs.modal', e => {
const b = e.relatedTarget;
document.getElementById('edit-id').value = b.getAttribute('data-id');
document.getElementById('edit-usuario').value = b.getAttribute('data-usuario');
document.getElementById('edit-fecha').value = b.getAttribute('data-fecha');
document.getElementById('edit-total').value = b.getAttribute('data-total');
document.getElementById('edit-estado').value = b.getAttribute('data-estado');
});
</script>

<?php include 'includes/footer.php'; ?>
