<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
  die("Error de conexión: " . $conn->connect_error);
}

$id = $_POST['id_categoria'];
$nombre = $_POST['nombre'];

$sql = "UPDATE CATEGORIAS SET nombre = ? WHERE id_categoria = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $nombre, $id);

if ($stmt->execute()) {
  echo "<script>alert('Categoría actualizada correctamente'); window.location='categorias.php';</script>";
} else {
  echo "<script>alert('Error al actualizar la categoría'); window.location='categorias.php';</script>";
}

$stmt->close();
$conn->close();
?>
