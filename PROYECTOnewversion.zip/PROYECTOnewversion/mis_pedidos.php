<?php
session_start();
date_default_timezone_set('America/Lima');

// Validar sesión
if (empty($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Conexión BD
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$idUsuario = $_SESSION['usuario_id'];

// 👉 NO mostrar cancelados
$sql = "
SELECT id_pedido, fecha, total, estado, archivo
FROM pedidos
WHERE id_usuario = ?
AND estado != 'Cancelado'
ORDER BY fecha DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
?>

<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mis Pedidos - Florería RS</title>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">

<style>
body { background: #fafafa; }
.titulo {
    font-size: 26px;
    font-weight: bold;
    background: linear-gradient(90deg, #ff7eb3, #ff758f, #ff6a88, #ff99ac);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
table { font-size: 15px; }
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
<div class="container">
<a class="navbar-brand" href="index.php">
<img src="logo.png" width="40" height="40" class="me-2">
Florería RS 🌸
</a>

<div class="collapse navbar-collapse">
<ul class="navbar-nav ms-auto align-items-center">
<li class="nav-item"><a href="index.php" class="nav-link">Inicio</a></li>
<li class="nav-item"><a href="carrito.php" class="nav-link">🛒 Carrito</a></li>
<li class="nav-item"><a href="mis_pedidos.php" class="nav-link active">Mis Pedidos</a></li>

<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle text-success fw-semibold" data-bs-toggle="dropdown">
👤 <?= htmlspecialchars($_SESSION['usuario_nombre'] ?? 'Usuario') ?>
</a>
<ul class="dropdown-menu dropdown-menu-end">
<li><a class="dropdown-item" href="cambiar_password.php">Cambiar contraseña</a></li>
<li><hr class="dropdown-divider"></li>
<li><a class="dropdown-item text-danger" href="logout.php">Cerrar sesión</a></li>
</ul>
</li>
</ul>
</div>
</div>
</nav>

<div class="container mt-5">
<h3 class="text-center titulo">📦 Mis Pedidos</h3>

<div class="text-center mb-3">
<a href="reporte_pedidos.php" class="btn btn-danger">📄 Ver reporte</a>
</div>

<?php if ($result->num_rows > 0): ?>
<div class="table-responsive">
<table class="table table-hover table-striped align-middle">
<thead class="table-dark">
<tr>
<th># Pedido</th>
<th>Fecha</th>
<th>Total (S/)</th>
<th>Estado</th>
<th>Comprobante</th>
<th>Abrir</th>
<th>Acción</th>
</tr>
</thead>

<tbody>
<?php while ($row = $result->fetch_assoc()):
$archivo = trim($row['archivo']);
$ruta = "admin_php/subidas/$archivo";
?>
<tr>
<td><?= $row['id_pedido'] ?></td>
<td><?= date("d/m/Y H:i", strtotime($row['fecha'])) ?></td>
<td><?= number_format($row['total'], 2) ?></td>

<td>
<?php if ($row['estado']=='Pendiente'): ?>
<span class="badge bg-warning text-dark">Pendiente</span>
<?php else: ?>
<span class="badge bg-success"><?= $row['estado'] ?></span>
<?php endif; ?>
</td>

<td>
<?php if (!empty($archivo) && file_exists($ruta)): ?>
<a href="<?= $ruta ?>" target="_blank"><?= $archivo ?></a>
<?php else: ?>
<span class="text-muted">---</span>
<?php endif; ?>
</td>

<td>
<?php if (!empty($archivo) && file_exists($ruta)): ?>
<a href="<?= $ruta ?>" target="_blank" class="btn btn-sm btn-primary">Abrir</a>
<?php else: ?>
—
<?php endif; ?>
</td>

<td>
<?php if ($row['estado']=='Pendiente'): ?>
<form action="cancelar_pedido.php" method="POST"
onsubmit="return confirm('¿Seguro de cancelar este pedido?');">
<input type="hidden" name="id_pedido" value="<?= $row['id_pedido'] ?>">
<button class="btn btn-sm btn-danger">Cancelar</button>
</form>
<?php else: ?>
—
<?php endif; ?>
</td>

</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<?php else: ?>
<div class="alert alert-info text-center">
No tienes pedidos registrados 🌿
</div>
<?php endif; ?>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
