<?php
session_start();

// Config BD
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'floreria_sr');

$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) {
    die("Error de conexión.");
}

$mensaje = "";
$nombre = "";
$correo = "";
$telefono = "";
$direccion = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST['nombre'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $clave = $_POST['clave'] ?? '';

    if (empty($nombre) || empty($correo) || empty($telefono) || empty($direccion) || empty($clave)) {
        $mensaje = "Complete todos los campos.";
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $mensaje = "El correo es inválido.";
    } else {

        // Verificar si el correo ya existe
        $sql = "SELECT id_usuario FROM usuarios WHERE correo = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $mensaje = "El correo ya está registrado.";
        } else {

            $claveHash = password_hash($clave, PASSWORD_DEFAULT);
            $rol = "cliente"; // 🔒 ROL AUTOMÁTICO
            $creado_en = date("Y-m-d H:i:s");

            $sqlInsert = "INSERT INTO usuarios 
            (nombre, correo, telefono, direccion, clave, rol, creado_en) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";

            $stmtInsert = $conn->prepare($sqlInsert);
            $stmtInsert->bind_param(
                "sssssss",
                $nombre,
                $correo,
                $telefono,
                $direccion,
                $claveHash,
                $rol,
                $creado_en
            );

            if ($stmtInsert->execute()) {
                $_SESSION['usuario_id'] = $stmtInsert->insert_id;
                $_SESSION['usuario_nombre'] = $nombre;
                $_SESSION['usuario_rol'] = $rol;

                header("Location: index.php");
                exit;
            } else {
                $mensaje = "Error al crear la cuenta.";
            }
        }
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Crear Cuenta - Florería SR</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-5">
<div class="card shadow">
<div class="card-header bg-success text-white text-center">
    <h4>Crear Cuenta</h4>
</div>
<div class="card-body">

<?php if (!empty($mensaje)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($mensaje) ?></div>
<?php endif; ?>

<form method="POST">
<div class="mb-3">
<label class="form-label">Nombre completo</label>
<input type="text" class="form-control" name="nombre" value="<?= htmlspecialchars($nombre) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Correo electrónico</label>
<input type="email" class="form-control" name="correo" value="<?= htmlspecialchars($correo) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Teléfono</label>
<input type="text" class="form-control" name="telefono" value="<?= htmlspecialchars($telefono) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Dirección</label>
<input type="text" class="form-control" name="direccion" value="<?= htmlspecialchars($direccion) ?>" required>
</div>

<div class="mb-3">
<label class="form-label">Contraseña</label>
<input type="password" class="form-control" name="clave" required>
</div>

<button class="btn btn-success w-100">Crear cuenta</button>
</form>

<p class="text-center mt-3">
¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
</p>

</div>
</div>
</div>
</div>
</div>

</body>
</html>
