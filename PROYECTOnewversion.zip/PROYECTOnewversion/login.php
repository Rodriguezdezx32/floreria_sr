<?php
session_start();

// Config BD
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'floreria_sr');

$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if ($conn->connect_error) { die("Error de conexión."); }

$error = "";
$correo = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $correo = trim($_POST['correo'] ?? '');
    $clave = $_POST['clave'] ?? '';

    if (empty($correo) || empty($clave)) {
        $error = "Por favor, complete todos los campos.";
    } else {
        $sql = "SELECT id_usuario, nombre, clave, rol FROM usuarios WHERE correo = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $correo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $usuario = $result->fetch_assoc();

            if (password_verify($clave, $usuario['clave'])) {
                $_SESSION['usuario_id'] = $usuario['id_usuario'];
                $_SESSION['usuario_nombre'] = $usuario['nombre'];
                $_SESSION['usuario_rol'] = $usuario['rol'];

                if ($usuario['rol'] === 'admin') {
                    header("Location: /proyectonewversion/admin_php/index.php");
                } else {
                    header("Location: index.php");
                }
                exit;
            }
        }
        $error = "Correo o contraseña incorrectos.";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<title>Iniciar Sesión - Florería SR</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
<div class="row justify-content-center">
<div class="col-md-5">
<div class="card shadow">
<div class="card-header bg-primary text-white text-center"><h4>Iniciar Sesión</h4></div>
<div class="card-body">

<?php if (!empty($error)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST">
<div class="mb-3">
<label class="form-label">Correo electrónico</label>
<input type="email" class="form-control" name="correo" value="<?= htmlspecialchars($correo) ?>" required>
</div>
<div class="mb-3">
<label class="form-label">Contraseña</label>
<input type="password" class="form-control" name="clave" required>
</div>
<button class="btn btn-primary w-100">Ingresar</button>
</form>

<p class="text-center mt-3">
¿No tienes cuenta? <a href="registro.php">Crea una aquí</a>
</p>

</div>
</div>
</div>
</div>
</div>

</body>
</html>
