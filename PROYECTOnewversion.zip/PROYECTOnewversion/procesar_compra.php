<?php
session_start();

/* ===============================
   VALIDAR SESIÓN
================================ */
if (empty($_SESSION['usuario_id'])) {
    die("Sesión no iniciada.");
}
$id_usuario = intval($_SESSION['usuario_id']);

/* ===============================
   VALIDAR CARRITO
================================ */
if (empty($_SESSION['carrito'])) {
    die("El carrito está vacío.");
}

/* ===============================
   VALIDAR FORM
================================ */
if (empty($_POST['pago']) || empty($_POST['entrega'])) {
    die("Debe seleccionar método de pago y tipo de entrega.");
}

$pago    = $_POST['pago'];
$entrega = $_POST['entrega'];

/* ===============================
   CONEXIÓN BD
================================ */
$conn = new mysqli("localhost","root","","floreria_sr");
if ($conn->connect_error) {
    die("Error conexión");
}
$conn->begin_transaction();

try {

    /* ===============================
       TOTAL
    ================================ */
    $total = 0;
    foreach ($_SESSION['carrito'] as $i) {
        $total += $i['cantidad'] * $i['precio'];
    }

    /* ===============================
       INSERT PEDIDO
    ================================ */
    $stmt = $conn->prepare("
        INSERT INTO pedidos (id_usuario, fecha, total, estado, pago, entrega, archivo)
        VALUES (?, NOW(), ?, 'Pendiente', ?, ?, '')
    ");
    $stmt->bind_param("idss",$id_usuario,$total,$pago,$entrega);
    $stmt->execute();
    $id_pedido = $stmt->insert_id;
    $stmt->close();

    /* ===============================
       STOCK
    ================================ */
    $upd = $conn->prepare("
        UPDATE productos 
        SET stock = stock - ?
        WHERE id_producto = ? AND stock >= ?
    ");
    foreach ($_SESSION['carrito'] as $i) {
        $c = intval($i['cantidad']);
        $p = intval($i['id']);
        $upd->bind_param("iii",$c,$p,$c);
        $upd->execute();
        if ($upd->affected_rows === 0) {
            throw new Exception("Stock insuficiente");
        }
    }
    $upd->close();

    /* ===============================
       PDF 80MM REAL
    ================================ */
    require_once __DIR__."/fpdf/fpdf.php";

    $carpeta = __DIR__."/admin_php/subidas/";
    if (!file_exists($carpeta)) mkdir($carpeta,0777,true);

    $pdf = new FPDF('P','mm',[80,200]);
    $pdf->SetMargins(4,4,4);   // 🔥 CLAVE
    $pdf->SetAutoPageBreak(true,4);
    $pdf->AddPage();

    /* ===== ENCABEZADO ===== */
    if (file_exists("logo.png")) {
        $pdf->Image("logo.png",4,6,16);
    }

    $pdf->SetXY(22,6);
    $pdf->SetFont('Arial','B',13);
    $pdf->Cell(0,6,"FLORERiA SR",0,1);

    $pdf->SetFont('Arial','',9);
    $pdf->SetX(22);
    $pdf->Cell(0,5,"Av. Principal 123 - Lima",0,1);
    $pdf->SetX(22);
    $pdf->Cell(0,5,"Tel: 924881335",0,1);

    $pdf->Ln(2);
    $pdf->Cell(0,0,str_repeat('-',32),0,1,'C');
    $pdf->Ln(2);

    /* ===== DATOS ===== */
    $pdf->SetFont('Arial','',9);
    $pdf->Cell(0,5,"Pedido #: $id_pedido",0,1);
    $pdf->Cell(0,5,"Fecha: ".date("d/m/Y H:i"),0,1);
    $pdf->Cell(0,5,"Pago: $pago",0,1);
    $pdf->Cell(0,5,"Entrega: $entrega",0,1);

    $pdf->Ln(2);
    $pdf->Cell(0,0,str_repeat('-',32),0,1,'C');
    $pdf->Ln(2);

    /* ===== CABECERA ===== */
    // TOTAL ANCHO USABLE = 72mm
    $pdf->SetFont('Arial','B',9);
    $pdf->Cell(28,5,"Producto",0);
    $pdf->Cell(8,5,"Cant",0,0,'C');
    $pdf->Cell(14,5,"Precio",0,0,'R');
    $pdf->Cell(22,5,"Subtotal",0,1,'R');

    $pdf->SetFont('Arial','',9);

    /* ===== DETALLE ===== */
    foreach ($_SESSION['carrito'] as $i) {

        $sub = $i['cantidad'] * $i['precio'];
        $y = $pdf->GetY();

        $pdf->MultiCell(28,5,utf8_decode($i['nombre']),0);
        $h = $pdf->GetY() - $y;

        $pdf->SetXY(4+28,$y);
        $pdf->Cell(8,$h,$i['cantidad'],0,0,'C');
        $pdf->Cell(14,$h,"S/ ".number_format($i['precio'],2),0,0,'R');
        $pdf->Cell(22,$h,"S/ ".number_format($sub,2),0,1,'R');
    }

    /* ===== TOTAL ===== */
    $pdf->Ln(2);
    $pdf->Cell(0,0,str_repeat('-',32),0,1,'C');
    $pdf->Ln(3);

    $pdf->SetFont('Arial','B',11);
    $pdf->Cell(50,6,"TOTAL:",0,0,'R');
    $pdf->Cell(22,6,"S/ ".number_format($total,2),0,1,'R');

    $pdf->Ln(4);
    $pdf->SetFont('Arial','',9);
    $pdf->Cell(0,5,"Gracias por su compra",0,1,'C');

    $nombrePDF = "pedido_".date("YmdHis")."_u{$id_usuario}.pdf";
    $pdf->Output("F",$carpeta.$nombrePDF);

    $up = $conn->prepare("UPDATE pedidos SET archivo=? WHERE id_pedido=?");
    $up->bind_param("si",$nombrePDF,$id_pedido);
    $up->execute();
    $up->close();

    $conn->commit();
    unset($_SESSION['carrito']);
    header("Location: index.php?pedido_ok=1");
    exit();

} catch (Exception $e) {
    $conn->rollback();
    die("Error: ".$e->getMessage());
}
