<?php
session_start();
date_default_timezone_set('America/Lima');

// Verificar que el usuario esté logueado
if (empty($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

$mensaje = "";

// Procesar el formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $actual = $_POST['actual'] ?? '';
    $nueva = $_POST['nueva'] ?? '';
    $confirmar = $_POST['confirmar'] ?? '';
    $idUsuario = $_SESSION['usuario_id'];

    if (empty($actual) || empty($nueva) || empty($confirmar)) {
        $mensaje = "<div class='alert alert-danger'>Todos los campos son obligatorios.</div>";
    } elseif ($nueva !== $confirmar) {
        $mensaje = "<div class='alert alert-warning'>La nueva contraseña no coincide.</div>";
    } else {
        // Obtener contraseña actual
        $sql = "SELECT clave FROM usuarios WHERE id_usuario = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("Error SQL: " . $conn->error);
        }

        $stmt->bind_param("i", $idUsuario);
        $stmt->execute();
        $stmt->bind_result($hashActual);
        $stmt->fetch();
        $stmt->close();

        // Verificar contraseña actual
        if (!password_verify($actual, $hashActual)) {
            $mensaje = "<div class='alert alert-danger'>La contraseña actual es incorrecta.</div>";
        } else {
            // Guardar nueva contraseña
            $nuevoHash = password_hash($nueva, PASSWORD_BCRYPT);

            $sqlUpdate = "UPDATE usuarios SET clave = ? WHERE id_usuario = ?";
            $stmt2 = $conn->prepare($sqlUpdate);
            $stmt2->bind_param("si", $nuevoHash, $idUsuario);

            if ($stmt2->execute()) {
                $mensaje = "<div class='alert alert-success'>Contraseña cambiada con éxito 🎉</div>";
            } else {
                $mensaje = "<div class='alert alert-danger'>Error al actualizar la contraseña.</div>";
            }

            $stmt2->close();
        }
    }
}

$conn->close();
?>

<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cambiar contraseña</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { background: #f8f9fa; }
        .card {
            border: none; border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,.1);
        }
        .btn-guardar {
            background: linear-gradient(90deg, #ff7eb3, #ff758f);
            color: white; border: none;
        }
        .btn-guardar:hover {
            background: linear-gradient(90deg, #ff6a88, #ff99ac);
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4">
                <h4 class="text-center mb-3">🔐 Cambiar Contraseña</h4>

                <?= $mensaje ?>

                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Contraseña actual</label>
                        <input type="password" name="actual" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nueva contraseña</label>
                        <input type="password" name="nueva" class="form-control" required minlength="6">
                        <div class="form-text">Mínimo 6 caracteres</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Confirmar contraseña</label>
                        <input type="password" name="confirmar" class="form-control" required>
                    </div>

                    <button class="btn btn-guardar w-100">Guardar cambios</button>
                </form>

                <a href="index.php" class="d-block mt-3 text-center">⬅ Volver al inicio</a>
            </div>
        </div>
    </div>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
