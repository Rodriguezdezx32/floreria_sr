<?php
session_start();
date_default_timezone_set('America/Lima');

/* SALUDO */
$hora = date("H");
if ($hora >= 5 && $hora < 12) {
    $saludo = "🌅 ¡Buenos días!";
} elseif ($hora >= 12 && $hora < 18) {
    $saludo = "🌞 ¡Buenas tardes!";
} else {
    $saludo = "🌙 ¡Buenas noches!";
}

/* SEGURIDAD */
if (empty($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

/* CONEXIÓN */
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

/* CATEGORÍAS */
$cats_result = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS ORDER BY nombre ASC");

/* FILTRO */
$where = "";
$categoriaSeleccionada = null;

if (!empty($_GET['categoria'])) {
    $categoriaSeleccionada = intval($_GET['categoria']);
    $where = "WHERE p.id_categoria = $categoriaSeleccionada";
}

/* CONSULTA CON STOCK */
$sql = "
SELECT 
    p.id_producto,
    p.nombre,
    p.descripcion,
    p.precio,
    p.stock,
    p.imagen_url,
    c.nombre AS categoria
FROM PRODUCTOS p
JOIN CATEGORIAS c ON p.id_categoria = c.id_categoria
$where
ORDER BY p.id_producto ASC
";
$result = $conn->query($sql);
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Catálogo - Florería RS</title>

<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/all.min.css" rel="stylesheet">

<style>
.card-img-top {
    height: 240px;
    object-fit: contain;
    background: #fff;
}

.titulo-catalogo {
    font-size: 28px;
    font-weight: bold;
    background: linear-gradient(90deg, #ff7eb3, #ff758f, #ff6a88);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.btn-comprar {
    background: linear-gradient(90deg, #74c69d, #52b788);
    border: none;
    color: white;
}
.btn-comprar:hover {
    background: linear-gradient(90deg, #52b788, #40916c);
}

.btn-agotado {
    background: #adb5bd;
    color: white;
    cursor: not-allowed;
}
</style>
</head>

<body class="bg-light">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
<div class="container">
<a class="navbar-brand" href="index.php">
<img src="logo.png" width="40"> <span>Florería RS 🌸</span>
</a>

<div class="collapse navbar-collapse">
<ul class="navbar-nav ms-auto">
<li class="nav-item"><a class="nav-link" href="carrito.php">🛒 Carrito</a></li>
<li class="nav-item"><a class="nav-link" href="mis_pedidos.php">Mis pedidos</a></li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
👤 <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
</a>
<ul class="dropdown-menu dropdown-menu-end">
<li><a class="dropdown-item" href="logout.php">Cerrar sesión</a></li>
</ul>
</li>
</ul>
</div>
</div>
</nav>

<div class="container mt-5">

<h3 class="text-center titulo-catalogo">✨ Nuestro Catálogo Floral</h3>

<p class="text-center text-muted"><?= $saludo ?> Bienvenido a Florería RS 🌸</p>

<!-- FILTRO -->
<form method="GET" class="text-center mb-4">
<select name="categoria" onchange="this.form.submit()" class="form-select w-auto d-inline">
<option value="">Todas</option>
<?php while ($cat = $cats_result->fetch_assoc()): ?>
<option value="<?= $cat['id_categoria'] ?>"
<?= ($categoriaSeleccionada == $cat['id_categoria']) ? 'selected' : '' ?>>
<?= htmlspecialchars($cat['nombre']) ?>
</option>
<?php endwhile; ?>
</select>
</form>

<?php if ($result->num_rows > 0): ?>
<div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">

<?php while ($row = $result->fetch_assoc()):
$img = $row['imagen_url'] ?: 'default.png';
$imgPath = "imagenes_productos/$img";
if (!file_exists($imgPath)) $imgPath = "imagenes_productos/default.png";
?>

<div class="col">
<div class="card h-100 shadow-sm">

<img src="<?= $imgPath ?>" class="card-img-top">

<div class="card-body">
<span class="badge bg-primary"><?= $row['categoria'] ?></span>

<h5 class="mt-2"><?= htmlspecialchars($row['nombre']) ?></h5>

<p class="small text-muted">
<?= htmlspecialchars(mb_strimwidth($row['descripcion'], 0, 90, '...')) ?>
</p>

<p class="fw-bold fs-5 text-primary">
S/ <?= number_format($row['precio'], 2) ?>
</p>

<p class="mb-2">
Stock:
<?php if ($row['stock'] > 0): ?>
<span class="badge bg-success"><?= $row['stock'] ?> disponibles</span>
<?php else: ?>
<span class="badge bg-danger">Agotado</span>
<?php endif; ?>
</p>

<?php if ($row['stock'] > 0): ?>
<a href="agregar_carrito.php?id=<?= $row['id_producto'] ?>"
class="btn btn-comprar w-100">
<i class="fa fa-shopping-cart"></i> Comprar
</a>
<?php else: ?>
<button class="btn btn-agotado w-100" disabled>
<i class="fa fa-ban"></i> Sin stock
</button>
<?php endif; ?>

</div>
</div>
</div>

<?php endwhile; ?>
</div>

<?php else: ?>
<div class="alert alert-info text-center">
No hay productos disponibles.
</div>
<?php endif; ?>

</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
