<?php
// ¡Paso CRÍTICO! Iniciar la sesión para verificar si el usuario está logeado
session_start();

$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión a la base de datos.");
}

// 1. Determinar el estado de la sesión
$redireccion_login = empty($_SESSION['usuario_id']); 

// Consulta para obtener productos
$result = $conn->query("
    SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.stock, c.nombre AS categoria
    FROM PRODUCTOS p
    JOIN CATEGORIAS c ON p.id_categoria = c.id_categoria
");
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Catálogo de Productos - Florería RS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
    </style>
</head>
<body class="bg-light">

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
        <div class="container">

            <a class="navbar-brand" href="index.php">
                <img src="logo.png" alt="Florería RS Logo" width="40" height="40" class="d-inline-block align-text-center me-2">
                <span class="fw-bold text-dark">Florería RS 🌸</span>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav ms-auto">

                    <a href="index.php" class="nav-link active">Inicio</a>

                    <?php if ($redireccion_login): ?>

                        <!-- Usuario NO logeado -->
                        <a href="login.php" class="nav-link">Iniciar sesión</a>

                    <?php else: ?>

                        <!-- Usuario SI logeado -->
                        <span class="nav-link fw-bold text-primary">
                            👤 <?= htmlspecialchars($_SESSION['usuario_nombre']) ?>
                        </span>

                        <a href="logout.php" class="nav-link text-danger">Cerrar sesión</a>

                    <?php endif; ?>

                    <a href="carrito.php" class="nav-link">🛒 Carrito</a>
                    <a href="pedidos.php" class="nav-link">Mis Pedidos</a>

                </div>
            </div>

        </div>
    </nav>

    <hr class="mt-0"/>

    <!-- CONTENIDO -->
    <div class="container mt-5">
        <h3 class="mb-4 text-center text-secondary">✨ Nuestro Catálogo Floral</h3>
        
        <?php if ($result->num_rows > 0): ?>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col">
                        <div class="card h-100 shadow-sm border-0">

                            <img src="https://www.floresenelmundo.com/images/products/500x500/ramo-de-rosas-lirios_1.png" 
                                 class="card-img-top" 
                                 alt="<?= htmlspecialchars($row['nombre']) ?>">

                            <div class="card-body">
                                <div>
                                    <span class="badge bg-success text-white mb-2"><?= htmlspecialchars($row['categoria']) ?></span>
                                    <h5 class="card-title"><?= htmlspecialchars($row['nombre']) ?></h5>
                                    <p class="card-text text-muted small"><?= htmlspecialchars(substr($row['descripcion'], 0, 80)) . '...' ?></p>
                                </div>
                                
                                <div class="mt-3 text-end">
                                    <p class="fs-4 text-primary mb-1 text-start">S/ <?= number_format($row['precio'], 2) ?></p>
                                    
                                    <?php if ($row['stock'] > 0): ?>

                                        <?php 
                                            $accion_url = $redireccion_login 
                                                ? 'login.php' 
                                                : 'agregar_carrito.php?id=' . $row['id_producto'];
                                        ?>

                                        <a href="<?= $accion_url ?>" 
                                           class="btn btn-success w-100" 
                                           title="Añadir al Carrito">
                                            <i class="fa fa-shopping-cart"></i> Comprar
                                        </a>

                                    <?php else: ?>

                                        <button class="btn btn-danger w-100" disabled>
                                            <i class="fa fa-exclamation-triangle"></i> Agotado
                                        </button>

                                    <?php endif; ?>
                                    
                                    <p class="text-secondary small mt-2">Stock: <?= $row['stock'] ?></p>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>

            </div>

        <?php else: ?>

            <div class="alert alert-info text-center">No hay productos disponibles en el catálogo.</div>

        <?php endif; ?>
    </div>

    <?php $conn->close(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
