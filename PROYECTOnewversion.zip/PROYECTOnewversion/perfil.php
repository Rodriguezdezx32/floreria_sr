<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$id = $_SESSION["id_usuario"];

 d
$stmt = $conn->prepare("SELECT nombre, correo, telefono, direccion, clave, rol FROM usuarios WHERE id_usuario = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Usuario no encontrado");
}

$usuario = $result->fetch_assoc();
$stmt->close();

// Procesar actualización
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST["nombre"]);
    $correo = trim($_POST["correo"]);
    $telefono = trim($_POST["telefono"]);
    $direccion = trim($_POST["direccion"]);
    $clave = trim($_POST["clave"]); // Nueva contraseña opcional

    // Si NO escribe contraseña → se mantiene la actual
    if ($clave === "") {
        $sql = "UPDATE usuarios SET nombre = ?, correo = ?, telefono = ?, direccion = ? WHERE id_usuario = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $nombre, $correo, $telefono, $direccion, $id);

    } else {
        // Si escribe contraseña → se hashea
        $hash = password_hash($clave, PASSWORD_DEFAULT);

        $sql = "UPDATE usuarios SET nombre = ?, correo = ?, telefono = ?, direccion = ?, clave = ? WHERE id_usuario = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $nombre, $correo, $telefono, $direccion, $hash, $id);
    }

    if ($stmt->execute()) {
        // NO se destruye sesión → NO pide iniciar sesión de nuevo

        // Actualizar variables de sesión visibles
        $_SESSION["nombre"] = $nombre;
        $_SESSION["correo"] = $correo;

        header("Location: perfil.php?ok=1");
        exit;
    } else {
        echo "Error al actualizar: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Mi Perfil</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm p-4">
        <h3 class="mb-4">Editar Mi Perfil</h3>

        <?php if(isset($_GET['ok'])): ?>
            <div class="alert alert-success">Perfil actualizado correctamente.</div>
        <?php endif; ?>

        <form method="POST">

            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($usuario["nombre"]) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Correo</label>
                <input type="email" name="correo" class="form-control" value="<?= htmlspecialchars($usuario["correo"]) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Teléfono</label>
                <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($usuario["telefono"]) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Dirección</label>
                <textarea name="direccion" class="form-control"><?= htmlspecialchars($usuario["direccion"]) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Nueva contraseña (opcional)</label>
                <input type="password" name="clave" class="form-control">
                <small class="text-muted">Déjalo vacío para mantener la contraseña actual.</small>
            </div>

            <button type="submit" class="btn btn-primary w-100">Guardar Cambios</button>
        </form>

        <a href="dashboard.php" class="btn btn-secondary mt-3 w-100">Volver</a>
    </div>
</div>

</body>
</html>
