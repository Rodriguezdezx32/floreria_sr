<?php
session_start();
include "conexion.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id_pedido = $_GET['id'];

// Obtener datos del pedido
$sql = "SELECT archivo, total, fecha FROM pedidos WHERE id_pedido = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $id_pedido);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("El pedido no existe.");
}

$pedido = $result->fetch_assoc();
$archivo = $pedido['archivo'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Pedido Confirmado</title>

<style>
body{
    background:#111;
    color:#fff;
    font-family: Arial, sans-serif;
    margin:0;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}
.container{
    background:#1c1c1c;
    padding:35px;
    width:420px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 0 15px #000;
}
h2{
    color:#44ff6a;
    text-shadow:0 0 10px #44ff6a;
}
.btn{
    display:block;
    margin:15px auto;
    padding:12px;
    border-radius:10px;
    width:90%;
    text-decoration:none;
    font-size:18px;
    transition:.3s;
}
.descargar{
    background:#ffbf00;
    color:#000;
    font-weight:bold;
}
.descargar:hover{
    background:#e6a900;
    transform:scale(1.05);
}
.inicio{
    background:#ff4081;
    color:#fff;
}
.inicio:hover{
    background:#e83472;
    transform:scale(1.05);
}
</style>
</head>
<body>

<div class="container">
    <h2>✔ ¡Compra realizada con éxito!</h2>
    <p>Tu pedido <b>#<?= $id_pedido ?></b> ha sido registrado.</p>
    <p>Total pagado: <b>S/. <?= number_format($pedido['total'], 2) ?></b></p>
    <p>Fecha: <?= $pedido['fecha'] ?></p>

    <a class="btn descargar" href="pdf_pedidos/<?= $archivo ?>" target="_blank">
        📄 Descargar Factura PDF
    </a>

    <a class="btn inicio" href="index.php">🏠 Volver al inicio</a>
</div>

</body>
</html>
