<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // El índice debe ser el mismo en todo el bloque: 'upload_vaucher_venta'
    if (isset($_FILES['upload_vaucher_venta']) && $_FILES['upload_vaucher_venta']['error'] === UPLOAD_ERR_OK) {
        
        $fileTmpPath = $_FILES['upload_vaucher_venta']['tmp_name'];
        $fileName = basename($_FILES['upload_vaucher_venta']['name']);
        $uploadFolder = 'vaucher/';

        // Crear carpeta si no existe
        if (!is_dir($uploadFolder)) {
            mkdir($uploadFolder, 0755, true);
        }

        // Sanitizar nombre del archivo para evitar problemas
        $fileName = preg_replace('/[^A-Za-z0-9._-]/', '_', $fileName);

        $destination = $uploadFolder . $fileName;

        // Usar la función correcta
        if (move_uploaded_file($fileTmpPath, $destination)) {
            echo "Archivo subido: " . htmlspecialchars($fileName, ENT_QUOTES, 'UTF-8');
        } else {
            echo "Error al mover el archivo cargado.";
        }

    } else {
        echo "Ocurrió un error en la subida o no se envió archivo.";
    }
}
?>
