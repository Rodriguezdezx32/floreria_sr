<?php
session_start();

if (!isset($_SESSION['comprobante'])) {
    echo "<h2>No hay comprobante disponible</h2>";
    exit();
}

$comp = $_SESSION['comprobante'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Comprobante de Pedido</title>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 900px;
        margin: auto;
        padding: 25px;
        background: white;
    }

    h1 {
        text-align: center;
        color: #ff4081;
        font-size: 34px;
        margin-bottom: 5px;
    }

    h3 {
        text-align: center;
        font-weight: normal;
        margin-top: 0;
        color: #666;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 25px;
    }

    th {
        background: #ff4081;
        color: white;
        padding: 12px;
        font-size: 16px;
    }

    td {
        border: 1px solid #ccc;
        padding: 12px;
        font-size: 15px;
    }

    .box-total {
        margin-top: 30px;
        padding: 18px;
        background: #00e676;
        font-size: 22px;
        font-weight: bold;
        text-align: center;
        border-radius: 8px;
    }

    .pie {
        text-align: center;
        margin-top: 40px;
        font-style: italic;
        color: #444;
    }

</style>

</head>
<body>

<h1>Comprobante de Pedido</h1>
<h3>Florería SR - Sistema de Compras</h3>

<p><strong>ID de compra:</strong> <?= $comp['id_compra'] ?></p>
<p><strong>Cliente ID:</strong> <?= $comp['cliente_id'] ?></p>
<p><strong>Fecha:</strong> <?= $comp['fecha'] ?></p>

<table>
    <tr>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio</th>
        <th>Subtotal</th>
    </tr>

    <?php foreach ($comp['items'] as $p): ?>
    <tr>
        <td><?= $p['nombre'] ?></td>
        <td style="text-align:center;"><?= $p['cantidad'] ?></td>
        <td style="text-align:center;">S/ <?= number_format($p['precio'], 2) ?></td>
        <td style="text-align:center;">
            S/ <?= number_format($p['precio'] * $p['cantidad'], 2) ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<div class="box-total">
    TOTAL: S/ <?= number_format($comp['total'], 2) ?>
</div>

<p class="pie">Gracias por su compra. En breve confirmaremos su pedido.</p>

</body>
</html>
