<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Lista de Productos - Florería SR</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
  <style>
    body { background-color: #f4f8fb; }
    .navbar-brand { font-weight: bold; font-size: 1.5rem; }
    .table-hover tbody tr:hover { background-color: #f0f0f0; }
    .card-header i { margin-right: 8px; }
  </style>
</head>
<body>

<?php
$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) { die("Error de conexión: " . $conn->connect_error); }
?>

<!-- Encabezado -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="#"><i class="fa-solid fa-seedling"></i> Florería SR</a>
  </div>
</nav>

<!-- Navegación -->
<div class="container mt-4">
  <div class="card shadow-sm">
    <div class="card-header bg-light">
      <h5 class="mb-0"><i class="fa-solid fa-box"></i> Panel de administración</h5>
    </div>
    <a href="admin_php/blank.php" class="btn btn-secondary">
    <i class="fa-solid fa-arrow-left"></i> Regresar
</a>
    <div class="card-body">
      <div class="btn-group">
        <a href="usuarios.php" class="btn btn-outline-primary"><i class="fa-solid fa-user"></i> Usuarios</a>
        <a href="articulos.php" class="btn btn-outline-success"><i class="fa-solid fa-box"></i> Artículos</a>
        <a href="categorias.php" class="btn btn-outline-warning"><i class="fa-solid fa-tags"></i> Categorías</a>
        <a href="pedido.php" class="btn btn-outline-danger"><i class="fa-solid fa-truck"></i> Pedidos</a>
        <a href="subir_vaucher.php" class="btn btn-outline-danger"><i class="fa-solid fa-note"></i> Vaucher</a>
      </div>
    </div>
  </div>
</div>

<!-- Tabla de productos -->
<div class="container mt-4">
  <div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0"><i class="fa-solid fa-list"></i> Lista de Productos</h5>
    </div>
    <div class="card-body">
      <table class="table table-bordered table-hover">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Categoría</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $result = $conn->query("
            SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.stock,
                   c.nombre AS categoria, p.id_categoria AS id_categoria
            FROM PRODUCTOS p
            JOIN CATEGORIAS c ON p.id_categoria = c.id_categoria
          ");
          while ($row = $result->fetch_assoc()):
          ?>
          <tr>
            <td><?= $row['id_producto'] ?></td>
            <td><?= $row['nombre'] ?></td>
            <td><?= $row['descripcion'] ?></td>
            <td>S/ <?= number_format($row['precio'], 2) ?></td>
            <td><?= $row['stock'] ?></td>
            <td><?= $row['categoria'] ?></td>
            <td>
              <button class="btn btn-sm btn-warning"
                data-bs-toggle="modal"
                data-bs-target="#editModal"
                data-id="<?= $row['id_producto'] ?>"
                data-nombre="<?= $row['nombre'] ?>"
                data-descripcion="<?= $row['descripcion'] ?>"
                data-precio="<?= $row['precio'] ?>"
                data-stock="<?= $row['stock'] ?>"
                data-idcategoria="<?= $row['id_categoria'] ?>">
                <i class="fa fa-edit"></i>
              </button>
              <a href="eliminar_producto.php?id=<?= $row['id_producto'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Seguro de eliminar este producto?');">
                <i class="fa fa-trash"></i>
              </a>
            </td>
          </tr>
          <?php endwhile; ?>

          <!-- Fila para agregar nuevo producto -->
          <tr class="table-success">
            <form action="agregar_producto.php" method="POST">
              <td>Nuevo</td>
              <td><input type="text" name="nombre" class="form-control" required></td>
              <td><input type="text" name="descripcion" class="form-control" required></td>
              <td><input type="number" step="0.01" name="precio" class="form-control" required></td>
              <td><input type="number" name="stock" class="form-control" required></td>
              <td>
                <select name="id_categoria" class="form-select" required>
                  <option value="">Seleccione categoría</option>
                  <?php
                  $categorias = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS");
                  while ($cat = $categorias->fetch_assoc()):
                  ?>
                    <option value="<?= $cat['id_categoria'] ?>"><?= $cat['nombre'] ?></option>
                  <?php endwhile; ?>
                </select>
              </td>
              <td>
                <button type="submit" class="btn btn-sm btn-success">
                  <i class="fa fa-plus"></i> Agregar
                </button>
              </td>
            </form>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal de edición -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="editar_producto.php" method="POST">
        <div class="modal-header bg-info text-white">
          <h5 class="modal-title" id="editModalLabel"><i class="fa fa-edit"></i> Editar Producto</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_producto" id="edit-id">
          <div class="mb-3">
            <label for="edit-nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" name="nombre" id="edit-nombre" required>
          </div>
          <div class="mb-3">
            <label for="edit-descripcion" class="form-label">Descripción</label>
            <textarea class="form-control" name="descripcion" id="edit-descripcion" required></textarea>
          </div>
          <div class="mb-3">
            <label for="edit-precio" class="form-label">Precio</label>
            <input type="number" step="0.01" class="form-control" name="precio" id="edit-precio" required>
          </div>
          <div class="mb-3">
            <label for="edit-stock" class="form-label">Stock</label>
            <input type="number" class="form-control" name="stock" id="edit-stock" required>
          </div>
          <div class="mb-3">
            <label for="edit-id_categoria" class="form-label">Categoría</label>
            <select class="form-select" name="id_categoria" id="edit-id_categoria" required>
              <option value="">Seleccione categoría</option>
              <?php
              // Cargar categorías para el select del modal
              $categorias2 = $conn->query("SELECT id_categoria, nombre FROM CATEGORIAS");
              while ($cat2 = $categorias2->fetch_assoc()):
              ?>
                <option value="<?= $cat2['id_categoria'] ?>"><?= $cat2['nombre'] ?></option>
              <?php endwhile; ?>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar cambios</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
<script>
  const editModal = document.getElementById('editModal');
  editModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    document.getElementById('edit-id').value = button.getAttribute('data-id');
    document.getElementById('edit-nombre').value = button.getAttribute('data-nombre');
    document.getElementById('edit-descripcion').value = button.getAttribute('data-descripcion');
    document.getElementById('edit-precio').value = button.getAttribute('data-precio');
    document.getElementById('edit-stock').value = button.getAttribute('data-stock');
    // Preseleccionar la categoría en el select
    document.getElementById('edit-id_categoria').value = button.getAttribute('data-idcategoria');
  });
</script>

</body>
</html>
