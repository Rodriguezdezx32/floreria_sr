<?php
session_start();

$id = $_POST['id'];
$accion = $_POST['accion'];

if (!isset($_SESSION['carrito'][$id])) exit();

if ($accion === "sumar") {
    $_SESSION['carrito'][$id]['cantidad']++;
} elseif ($accion === "restar") {
    $_SESSION['carrito'][$id]['cantidad']--;
    if ($_SESSION['carrito'][$id]['cantidad'] <= 0) {
        unset($_SESSION['carrito'][$id]);
        echo json_encode(["eliminado" => true]);
        exit();
    }
}

$total = 0;
foreach ($_SESSION['carrito'] as $p) {
    $total += $p['precio'] * $p['cantidad'];
}

echo json_encode([
    "cantidad" => $_SESSION['carrito'][$id]['cantidad'],
    "total" => number_format($total, 2)
]);
