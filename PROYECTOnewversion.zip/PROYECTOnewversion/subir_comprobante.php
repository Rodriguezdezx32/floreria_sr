<?php
session_start();

// Validar sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id_pedido']) || !is_numeric($_GET['id_pedido'])) {
    die("Pedido no válido.");
}

$id_pedido = intval($_GET['id_pedido']);

// Si se envió el formulario
if (isset($_POST['subir'])) {

    if (!empty($_FILES['archivo']['name'])) {

        $nombreArchivo = time() . "_" . basename($_FILES['archivo']['name']);
        $ruta = "comprobantes/" . $nombreArchivo;

        // Crear carpeta si no existe
        if (!file_exists("comprobantes")) {
            mkdir("comprobantes", 0777, true);
        }

        if (move_uploaded_file($_FILES['archivo']['tmp_name'], $ruta)) {

            $conn = new mysqli("localhost", "root", "", "floreria_sr");

            $sql = "UPDATE pedidos SET archivo = '$ruta', estado='Pagado'
                    WHERE id_pedido = $id_pedido";

            $conn->query($sql);
            $conn->close();

            header("Location: ticket.php?id_pedido=" . $id_pedido);
            exit();
        } else {
            $error = "Error al subir el archivo.";
        }
    } else {
        $error = "Debes seleccionar un archivo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Subir Comprobante</title>
<style>
body { font-family: Arial; margin: 50px; }
.card { border:1px solid #ccc; padding: 20px; width: 450px; }
</style>
</head>
<body>

<h2>Subir Comprobante de Pago</h2>
<p>Pedido N° <?= $id_pedido ?></p>

<div class="card">
<form method="post" enctype="multipart/form-data">

    <label>Selecciona el comprobante (foto o PDF):</label><br><br>
    <input type="file" name="archivo" accept=".jpg,.jpeg,.png,.pdf"><br><br>

    <button type="submit" name="subir">Subir comprobante</button>
</form>

<?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
</div>

</body>
</html>
