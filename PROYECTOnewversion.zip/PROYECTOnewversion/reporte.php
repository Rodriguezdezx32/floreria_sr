<?php
require('fpdf/fpdf.php');
include('db.php');

class PDF extends FPDF
{
    function Header()
    {
        // Logo opcional
        // $this->Image('logo.png', 10, 8, 20);

        // Título
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, utf8_decode('Reporte de Pedidos'), 0, 1, 'C');
        $this->Ln(5);

        // Encabezados de la tabla
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(40, 167, 69);
        $this->SetTextColor(255, 255, 255);
        $this->Cell(25, 10, 'ID Pedido', 1, 0, 'C', true);
        $this->Cell(30, 10, 'ID Usuario', 1, 0, 'C', true);
        $this->Cell(40, 10, 'Fecha', 1, 0, 'C', true);
        $this->Cell(35, 10, 'Total (S/)', 1, 0, 'C', true);
        $this->Cell(40, 10, 'Estado', 1, 1, 'C', true);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 9);
        $this->SetTextColor(128);
        $this->Cell(0, 10, utf8_decode('Página ') . $this->PageNo(), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 11);
$pdf->SetTextColor(0);

// Consulta de datos
$sql = "SELECT * FROM pedidos";
$resultado = $conn->query($sql);

if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $pdf->Cell(25, 10, $fila['id_pedido'], 1, 0, 'C');
        $pdf->Cell(30, 10, $fila['id_usuario'], 1, 0, 'C');
        $pdf->Cell(40, 10, $fila['fecha'], 1, 0, 'C');
        $pdf->Cell(35, 10, number_format($fila['total'], 2), 1, 0, 'R');
        $pdf->Cell(40, 10, utf8_decode($fila['estado']), 1, 1, 'C');
    }
} else {
    $pdf->Cell(0, 10, 'No hay pedidos registrados', 1, 1, 'C');
}

// Salida del PDF
$pdf->Output('I', 'reporte_pedidos.pdf');
?>
