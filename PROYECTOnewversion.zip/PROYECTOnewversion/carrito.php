<?php
session_start();

// Verificar sesión
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Crear carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Calcular total
$total = 0;
foreach ($_SESSION['carrito'] as $producto) {
    $total += $producto['precio'] * $producto['cantidad'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Carrito de Compras</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #111;
            color: white;
            margin: 0;
        }

        .container {
            width: 90%;
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #ff4081;
            font-size: 32px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #222;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 20px;
        }

        th, td {
            padding: 16px;
            text-align: center;
        }

        th {
            background: #ff4081;
        }

        tr:nth-child(even) {
            background: #1a1a1a;
        }

        img {
            width: 90px;
            border-radius: 10px;
        }

        .volver {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 18px;
            background: #ff4081;
            color: white;
            text-decoration: none;
            border-radius: 10px;
        }

        .total {
            text-align: right;
            font-size: 26px;
            color: #00e676;
            font-weight: bold;
        }

        .btn-comprar {
            width: 100%;
            padding: 18px;
            background: #00e676;
            border: none;
            font-size: 18px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
        }

        .btn-eliminar {
            background: #e63946;
            padding: 10px 14px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
        }

        select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        h3 {
            color: #00e676;
            margin-top: 25px;
        }

        .empty-box {
            background: #242424;
            padding: 35px;
            border-radius: 12px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php" class="volver">⬅ Volver a productos</a>

    <h2>🛒 Tu Carrito</h2>

<?php if (count($_SESSION['carrito']) == 0) { ?>

    <div class="empty-box">
        <h3>🛍️ Tu carrito está vacío</h3>
        <p>Agrega productos para continuar</p>
    </div>

<?php } else { ?>

<form action="procesar_compra.php" method="POST">

    <table>
        <tr>
            <th>Producto</th>
            <th>Imagen</th>
            <th>Precio</th>
            <th>Cantidad</th>
            <th>Subtotal</th>
            <th>Acción</th>
        </tr>

        <?php foreach ($_SESSION['carrito'] as $p) { ?>
        <tr>
            <td><?= htmlspecialchars($p['nombre']) ?></td>
            <td>
                <img src="imagenes_productos/<?= htmlspecialchars($p['imagen']) ?>"
                     onerror="this.src='imagenes_productos/default.png'">
            </td>
            <td>S/ <?= number_format($p['precio'], 2) ?></td>
            <td><?= $p['cantidad'] ?></td>
            <td>S/ <?= number_format($p['precio'] * $p['cantidad'], 2) ?></td>
            <td>
                <a class="btn-eliminar"
                   href="eliminar_producto.php?id=<?= $p['id'] ?>">
                   Eliminar
                </a>
            </td>
        </tr>
        <?php } ?>
    </table>

    <p class="total">Total: S/ <?= number_format($total, 2) ?></p>

    <!-- MÉTODO DE PAGO -->
    <h3>💳 Método de pago</h3>
    <select name="pago" required>
        <option value="">Seleccione</option>
        <option value="Tarjeta">Tarjeta</option>
        <option value="Yape/Plin">Yape / Plin</option>
        <option value="Depósito">Depósito</option>
        <option value="Contraentrega">Contraentrega</option>
    </select>

    <!-- TIPO DE ENTREGA -->
    <h3>🚚 Tipo de entrega</h3>
    <select name="entrega" required>
        <option value="">Seleccione</option>
        <option value="Delivery">Delivery</option>
        <option value="Recojo en tienda">Recojo en tienda</option>
    </select>

    <button type="submit" class="btn-comprar">
        FINALIZAR COMPRA
    </button>

</form>

<?php } ?>

</div>

</body>
</html>
