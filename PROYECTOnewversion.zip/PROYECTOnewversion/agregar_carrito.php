<?php
session_start();

// Verificar si se recibe el ID del producto
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = intval($_GET['id']);

// Si no existe el carrito, lo creamos
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Si el producto YA está en el carrito → aumentar cantidad
if (isset($_SESSION['carrito'][$id])) {
    $_SESSION['carrito'][$id]['cantidad']++;
} else {

    // Conexión
    $conn = new mysqli("localhost", "root", "", "floreria_sr");
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }

    // Obtener datos del producto
    $sql = "SELECT id_producto, nombre, precio, imagen_url 
            FROM PRODUCTOS 
            WHERE id_producto = $id LIMIT 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $producto = $result->fetch_assoc();

        // Asegurar que la imagen exista
        $img = trim($producto['imagen_url']) !== "" ? $producto['imagen_url'] : "default.png";

        // Guardar en el carrito
        $_SESSION['carrito'][$id] = [
            "id"        => $producto['id_producto'],
            "nombre"    => $producto['nombre'],
            "precio"    => $producto['precio'],
            "imagen"    => $img,
            "cantidad"  => 1
        ];
    }
}

header("Location: carrito.php");
exit();
