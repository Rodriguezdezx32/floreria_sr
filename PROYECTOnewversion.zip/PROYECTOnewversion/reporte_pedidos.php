<?php
session_start();
date_default_timezone_set('America/Lima');

if (empty($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "floreria_sr");
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$idUsuario = $_SESSION['usuario_id'];

$sql = "SELECT id_pedido, fecha, total, estado 
        FROM pedidos 
        WHERE id_usuario = ? 
        ORDER BY fecha DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

require("fpdf/fpdf.php");

class PDF extends FPDF {

    function Header() {

        // Logo
        if (file_exists("logo.png")) {
            $this->Image("logo.png", 10, 8, 22);
        }

        // Título
        $this->SetFont('Arial', 'B', 20);
        $this->SetTextColor(230, 60, 110);
        $this->Ln(5);
        $this->Cell(0, 12, utf8_decode("REPORTE DE PEDIDOS"), 0, 1, "C");

        // Línea decorativa
        $this->SetDrawColor(230, 60, 110);
        $this->SetLineWidth(0.8);
        $this->Line(25, 32, 185, 32);

        // Subtítulo
        $this->SetFont('Arial', '', 12);
        $this->SetTextColor(100, 100, 100);
        $this->Ln(5);
        $this->Cell(0, 6, utf8_decode("Florería RS  Historial de compras"), 0, 1, "C");
        $this->Ln(5);

        // Encabezado tabla
        $this->SetFont('Arial', 'B', 11);
        $this->SetFillColor(255, 160, 190); // Rosado pastel
        $this->SetTextColor(40, 40, 40);

        $this->Cell(28, 10, "# Pedido", 1, 0, "C", true);
        $this->Cell(48, 10, "Fecha", 1, 0, "C", true);
        $this->Cell(38, 10, "Total (S/)", 1, 0, "C", true);
        $this->Cell(56, 10, "Estado", 1, 1, "C", true);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont("Arial", "I", 8);
        $this->SetTextColor(150, 150, 150);
        $this->Cell(0, 10, utf8_decode("Florería RS   Reporte generado el " . date("d/m/Y H:i")), 0, 0, "C");
    }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont("Arial", "", 11);
$pdf->SetTextColor(70, 70, 70);

$fill = false;
$totalGeneral = 0;

while ($row = $result->fetch_assoc()) {

    // Suma de total global
    $totalGeneral += $row["total"];

    // Colores alternados más suaves
    if ($fill) {
        $pdf->SetFillColor(255, 230, 240);  
    } else {
        $pdf->SetFillColor(255, 255, 255);
    }

    $pdf->Cell(28, 9, $row["id_pedido"], 1, 0, "C", $fill);
    $pdf->Cell(48, 9, date("d/m/Y H:i", strtotime($row["fecha"])), 1, 0, "C", $fill);
    $pdf->Cell(38, 9, "S/ " . number_format($row["total"], 2), 1, 0, "C", $fill);
    $pdf->Cell(56, 9, utf8_decode($row["estado"]), 1, 1, "C", $fill);

    $fill = !$fill;
}

// Espacio antes del total general
$pdf->Ln(5);

// Total general de compras
$pdf->SetFont("Arial", "B", 13);
$pdf->SetTextColor(230, 60, 110);
$pdf->Cell(0, 10, "Total general de compras: S/ " . number_format($totalGeneral, 2), 0, 1, "R");

$pdf->Output("I", "reporte_pedidos.pdf");
exit();
?>
